#Deleted from 626
/*$get_balance = $this->db->select('04_balance_left')
                                    ->where('04_id', $resdur['04_id'])
                                    ->get('company_04');
            $balance = $get_balance->row_array();
            $balance = $balance['04_balance_left'] - $resq['07_amount'];
            $this->db->where('04_id', $resdur['04_id'])->set('04_balance_left', $balance)->update('company_04');*/
            
            
#Deleted from 610

/*$get_balance = $this->db->select('04_balance_left')
                                    ->where('04_id', $resdur['04_id'])
                                    ->get('company_04');
            $balance = $get_balance->row_array();
            $balance = $balance['04_balance_left'] - $resq['07_amount'];
            $this->db->where('04_id', $resdur['04_id'])->set('04_balance_left', $balance)->update('company_04');*/
            
        
        
        
#Deleted from add money

            /*$get_balance = $this->db->select('04_balance_left')
                                    ->where('04_id', $resdur['04_id'])
                                    ->get('company_04');
            $balance = $get_balance->row_array();
            $balance = $balance['04_balance_left'] - $resq['07_amount'];
            $this->db->where('04_id', $resdur['04_id'])->set('04_balance_left', $balance)->update('company_04');*/