<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="description" content="Adzjar Delivering beyond expectation">
  <meta name="author" content="">
  <title>Adzjar | Delivering beyond expectation</title>
  <!-- Mobile Specific Meta-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="<?=base_url('images/favicon.png');?>" />
  <!-- Themefisher Icon font -->
  <link rel="stylesheet" href="<?=base_url('user-assets/plugins/themefisher-font/style.css');?>">
  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="<?=base_url('user-assets/plugins/bootstrap/css/bootstrap.min.css');?>">
  <!-- Revolution Slider -->
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/fonts/font-awesome/css/font-awesome.css');?>">
  <!-- REVOLUTION STYLE SHEETS -->
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/settings.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/layers.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/navigation.css');?>">
  
  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="<?=base_url('user-assets/css/style.css');?>">
</head>

<body id="body">
<!-- Start Top Header Bar -->
<section class="top-header">
	<div class="container" style="padding-top: 2px;padding-bottom: 5px;border: none;">
		<div class="row">
			<div class="col-md-12 col-xs-12 col-sm-4">
				<!-- Site Logo -->
				<div class="logo text-center"  style="width: 100%">
					<a href="<?=base_url('Users/dashboard');?>" class="profile-icon" style="float:left;margin-top:8px;"><i style="font-weight:bolder" class="tf-ion-help-circled"></i></a>
					<a href="<?=base_url('Users/treasure');?>"><h2 style="margin-top:5px;margin-bottom:2px">ADZJAR</h2></a>
					 <a href="<?=base_url('Users/logout');?>" class="profile-icon" style="float:right;margin-top:8px;padding-left:10px"><i style="font-weight:bolder" class="tf-ion-log-out"></i></a>
					<a href="<?=base_url('Users/dashboard');?>" class="profile-icon" style="float:right;margin-top:8px;"><i style="font-weight:bolder" class="tf-profile-male"></i></a>
					
				</div>
        	   </div><!-- / .nav .navbar-nav .navbar-right -->
			</div>
	    </div>
    </div>
</section><!-- End Top Header Bar -->
