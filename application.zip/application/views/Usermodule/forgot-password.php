<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>AdzJar - Single Video</title>

  <link rel="canonical" href="https://www.adzjar.com">
  <meta name="title" content="Adz Jar - Static Front-end content">
  <meta name="referrer" content="unsafe-url">
  <meta name="description" content="Adz Jar description">
  <!-- App CSS -->
  <style>

    html {
      box-sizing: border-box;
    }
    *,
    *::before,
    *::after {
      box-sizing: inherit;
    }
  </style>
  <link rel="stylesheet" href="<?=base_url('user-assets/css/style.css');?>">
  <link rel="stylesheet" href="<?=base_url('user-assets/css/custom.css');?>">
</head>
<body>
  <main class="main d-flex login-main">

    <div class="login mr-auto mb-auto ml-auto d-flex flex-column align-items-center">
      <!-- LOGIN LOGO -->
      <div class="login-logo">
        <a href="javascript:;">
          <img src="<?=base_url('user-assets/images_temp/logo.svg');?>" alt="Adz Jar Logo">
        </a>
      </div><!--/.login-logo-->
      
      <!-- LOGIN FORM -->
      <div class="login-card">
        <div class="card shadow-sm">
            <?php  # Warn user if error
                if($this->session->flashdata('error')){?>
                  <div class='alert alert-danger' style="font-size:14px">
                    <?=$this->session->flashdata('error')?>
                  </div>
                <?}if($this->session->flashdata('message')){?>
                  <div class='alert alert-success' style="font-size:14px">
                    <?=$this->session->flashdata('message');?>
                  </div>
                <?}?>
          <div class="card-header bg-white border-0 p-0">
            <h1>Forgot Password</h1>
            <p>Enter your register Email ID</p>
          </div> <!--/.card-header-->
          <div class="card-body p-0">
            <form class="login-form" id="forgot-form" method="post" action="<?=base_url('Users/send_email');?>">

              <div class="form-group login-phone d-flex flex-row">
                <div class="login-phone__number">
                  <input type="email" class="form-control" placeholder="Email ID" name="email">
                  <div class="invalid-feedback login-phone__error"></div>
                </div> <!--/.login-phone__number-->
              </div> <!--/.form-group-->

              <div class="form-group mb-0 login-form__submit">
                <input type="submit" class="btn btn-block btn-danger" value="Send Password">
                <div class="invalid-feedback login-form__error text-center mb-0 mt-2"></div>
              </div> <!--/.form-group-->

            </form> <!--/.login-form-->
          </div> <!--/.card-body-->
        </div>
      </div> <!--/.login-form-->
      <!-- END LOGIN FORM -->
      <!-- LOGIN SINGUP -->
      <div class="login-singup mt-4">
        <p>Don't have an account? <a href="<?=base_url('Users/register');?>">Click Here</a></p>
      </div> <!--/.login-singup -->
      <!-- END LOGIN SINGUP -->
    </div> <!--/.login-->

  </main> <!--/.main-->
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

<!-- Core JavaScript -->
<script src="<?=base_url('user-assets/third_party/modernizr.min.js');?>"></script>
</body>
</html>
