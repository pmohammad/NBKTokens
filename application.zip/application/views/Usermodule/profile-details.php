<? require_once('header.php');?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<script src="https://cdn.jsdelivr.net/sharer.js/latest/sharer.min.js"></script>

<style>
    .social{
        font-size:12px;
    }
    .fa{
        color:red;
    }
</style>

<div class="login-card" style="display: block;margin-right: auto;margin-left: auto;">
	<div class="card shadow-sm">
		<div class="card-header bg-white border-0 p-0">
			<h1>Profile</h1>
		</div> <!--/.card-header-->
		<?foreach($user as $key){?>
		<div class="card-body p-0">
			<form class="login-form" id="login-form" method="post">


					<div class="login-phone__number">
						<label><b>Name</b></label><br>
						<?=$key['01_name'];?>
					</div> <!--/.login-phone__number-->



				<div class="form-group">
					<label><b>Nationality</b></label><br>
					<?=$key['08_nationality'];?>
				</div> <!--/.form-group-->

				<div class="form-group">
					<label><b>Mobile Number</b></label><br>
					<?=$key['01_mobile'];?>
				</div> <!--/.form-group-->

				<div class="form-group">
					<label><b>Email</b></label><br>
					<?=$key['01_email'];?>
				</div> <!--/.form-group-->

				<div class="form-group">
					<label><b>Referral Link</b></label><br>
					<?$link = urlencode('http://adzjar.com/Users/register?referral='.$key['01_referring_code']);?>
                    <div class="social">
                        <a href="https://api.whatsapp.com/send?phone=&text=<?='I have found an amazing program to earn without any work. Please use below link to register and enjoy. '.$link?>" id="share-wa" class="sharer button">
                            <i class="fa fa-3x fa-whatsapp"></i></a>
                        <a href="#" id="share-fb" class="sharer button"><i class="fa fa-3x fa-facebook-square"></i></a>
                        <a href="#" id="share-tw" class="sharer button"><i class="fa fa-3x fa-twitter-square"></i></a>
                        <a href="#" id="share-li" class="sharer button"><i class="fa fa-3x fa-linkedin-square"></i></a>
                        <a href="#" id="share-gp" class="sharer button"><i class="fa fa-3x fa-google-plus-square"></i></a>
                        <a href="#" id="share-em" class="sharer button"><i class="fa fa-3x fa-envelope-square"></i></a>
                    </div>
				</div> <!--/.form-group-->

				<div class="form-group">
					<label><b>Total Referral</b></label><br>
					<?=$key['01_total_refer'];?>
				</div> <!--/.form-group-->
				<div class="form-group">
					<label><b>KYC Status</b></label><br>
					
					<?if($this->session->is_bank_details==0){
					    echo 'Bank details are not found';
					}else if($key['is_verify']==1){
					    echo 'Verified';
					}else if($key['is_verify']==2){
					    echo 'Rejected - '.$key['16_message'];
					}else if($key['is_verify']==0){
					    echo 'Waiting For Approval';
					}
					?>
					
				</div> <!--/.form-group-->
				
				<div class="row">
				<div class="form-group mb-0 login-form__submit col-md-6">
		            <a href="<?=base_url('Users/edit_profile');?>" class="btn btn-block btn-danger">Edit Profile</a>
		        </div>
		        <div class="form-group mb-0 login-form__submit col-md-6">
		            <?if($this->session->is_bank_details==1){?>
		                <a href="<?=base_url('Users/edit_bank_details');?>" class="btn btn-block btn-primary">Edit Bank Details</a>
		            <?}else{?>
		                <a href="<?=base_url('Users/add_bank_details');?>" class="btn btn-block btn-info">Add Bank Details</a>
		            <?}?>
		        </div>
		        </div>
			</form> <!--/.login-form-->
		</div> <!--/.card-body-->
		<?}?>
	</div>
</div> <!--/.login-form-->
<? require_once('footer.php');?>
