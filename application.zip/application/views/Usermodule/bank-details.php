<?require_once('header.php');?>

<div class="login-card" style="display: block;margin-right: auto;margin-left: auto;">
	<div class="card shadow-sm">
		<div class="card-header bg-white border-0 p-0">
			<h1>Add Bank Details</h1>
		</div> <!--/.card-header-->
		    <form method="post" action="<?php echo base_url('Users/update_bankdetails'); ?>" autocomplete="off" enctype="multipart/form-data" id="submit">
		        <div class="form-group">
                    <label>Account Name</label>
                    <input class="form-control" name="acc_name" id="acc_name" type="text" required placeholder="Bank Account Name" >
                </div> <!--/.form-group-->
                <div class="form-group">
                    <label>Select Bank</label>
                    <select class="form-control" name="banks" id="banks">
                        <option diabled value="default">Select Bank</option>
                        <?foreach($banks as $key){?>
                            <option value="<?=$key['bank_id'];?>"><?=$key['name'];?></option>
                        <?}?>
                    </select>
                </div> <!--/.form-group-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Civil ID (Front)</label>
                            <input class="form-control" name="civil_front" id="civil_front" type="file" required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Civil Id (Back)</label>
                            <input class="form-control" id="civil_back" name="civil_back" type="file" required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>IBAN</label>
                            <input class="form-control" id="hash" name="hash" type="text" placeholder="IBAN" required autocomplete="off" maxlength="16" minlength="16"> 
                            <input id="id" name="id" type="text" hidden value='<?=$balance['01_id']?>'>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="form-group pt-3">
                        <button type="submit" class="btn btn-danger btn-adzjar mr-2">Add Details</button>
                    </div> <!--/.form-group-->  
                </div>
                
            </form>
        </div>
    </div>
		
		
        
<?require_once('footer.php');?>