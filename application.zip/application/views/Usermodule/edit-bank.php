<?require_once('header.php');?>

<div class="login-card" style="display: block;margin-right: auto;margin-left: auto;">
	<div class="card shadow-sm">
		<div class="card-header bg-white border-0 p-0">
			<h1>Profile</h1>
		</div> <!--/.card-header-->
		<form method="post" action="<?php echo base_url('Users/update_user_bank'); ?>" autocomplete="off" enctype="multipart/form-data" id="submit">
		        <div class="form-group">
                    <label>Account Name</label>
                    <input class="form-control" name="acc_name" id="acc_name" type="text" required placeholder="Bank Account Name" value="<?=$bank_details['16_account_name']?>" >
                </div> <!--/.form-group-->
                <div class="form-group">
                    <label>Select Bank</label>
                    <select class="form-control" name="banks" id="banks">
                        <option diabled value="default">Select Bank</option>
                        <?foreach($banks as $key){?>
                            <option value="<?=$key['bank_id'];?>" <?if($key['bank_id']==$bank_details['bank_id']){?>selected<?}?>><?=$key['name'];?></option>
                        <?}?>
                    </select>
                </div> <!--/.form-group-->
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Civil ID (Front)</label>
                            <img src="<?=base_url($bank_details['16_civil_front']);?>" height="100px" width="100px">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Civil Id (Back)</label>
                            <img src="<?=base_url($bank_details['16_civil_back']);?>" height="100px" width="100px">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>IBAN</label>
                            <input class="form-control" id="hash" name="hash" type="text" placeholder="IBAN" required autocomplete="off" maxlength="16" minlength="16" value="<?=$bank_details['16_iban']?>"> 
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="form-group pt-3">
                        <button type="submit" class="btn btn-danger btn-adzjar mr-2">Update Details</button>
                    </div> <!--/.form-group-->  
                </div>
                
            </form>
        </div>
    </div>
		
		
        
<?require_once('footer.php');?>