<?require_once('header.php');?>

<div class="main-content d-flex flex-row">
      <div class="main-container">
        <div class="main-header">
          <div class="video-banner">
            <img src="<?=base_url('../user-assets/images_temp/video-banner2.png');?>" alt="Video Banner">
          </div> <!--/.video-banner-->
        </div> <!--/.main-header-->
        <!-- VIDEO CONTENT-->
        <div class="main-video">
            <div class="video-header">
                <h2>You will earn KWD <?=$vid['06_price'];?></h2>
                <p>Don’t Close in Between</p>
            </div> <!--/.video-header-->
            <?if($vid['05_type']==1){?>
                <div class="video-player" id="player" style="max-width:100%;"></div> <!--/.video-player-->
            <?}else if($vid['05_type']==0){?>
            <div class="col-md-12" style="padding:0px">
                <iframe src="<?=$vid['05_link']?>" height="415px" width="100%"></iframe>
            </div>
            <?}?>
          <div class="video-info">
            <span id="seconds"></span>
            <div id="playbtn" style="position: relative;margin-top: 27px;"></div>
          </div> <!--/.video-info-->
        </div> <!--/.video-->
        <!-- END VIDEO CONTENT -->
      </div> <!--/.main-container-->
      <div class="main-banner d-none d-sm-flex">
        <div class="main-banner__wrap">
          <img src="<?=base_url('../user-assets/images_temp/main-banner.png');?>" alt="Main Banner">
        </div> <!--/.main-banner__wrap-->
      </div> <!--/.main-banner-->
    </div> <!--/.main-content-->

<?require_once('footer.php');
$S = $vid['05_seconds'];

?>

<script>
 var dorun=0;
 var duration=<?=$S;?>;
 var video_time = duration;
 var doend=0;
 totalwatch = 0;
 var myinterval;
      var tag = document.createElement('script');

      tag.src = "https://www.youtube.com/iframe_api";
      var firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
      var player;
    function onYouTubeIframeAPIReady() {
        player = new YT.Player('player', {
          videoId: '<?=$vid['05_link']?>',
          width:'560',
          height:'315',
          playerVars: {
             color: 'white',
             controls: '0',
             autoplay: '0',
             disablekb:'1',
             rel:      '0',
             showinfo: '0',
          },
          events: {
            'onReady': initialize,
            'onStateChange': onPlayerStateChange
          }
        });
    }
    function initialize(){
    }
    function startvideo(){
        player.playVideo();
    }
    <?if($vid['05_type']==0){?>
        dorun=1;
        myinterval=setInterval(decduration,1000);
    <?}?>
    function decduration(){
        if(duration>0 && dorun==1){
            duration=duration-1;
        }
        totalwatch = totalwatch+1;
        document.getElementById("seconds").innerHTML=duration+" seconds remaining";
        <?if($vid['05_type']==0){?>
            if(totalwatch>5 && totalwatch<7){
                $.ajax({
                    type: "POST",
                    url: '<?=base_url("../Users/set_timeout")?>',
                    data: {time:totalwatch, id: '<?=$vid['06_id'];?>', type: '<?=$vid['05_type'];?>'},
                    success: function(data){
                        
                    }
                });
            }
        <?}?>
        if (duration<=0){
           doend=1;
           document.getElementById("playbtn").innerHTML="<input type='button' class='video-more__button shadow-sm' style='color:red'  value='Pay Me <?=$vid['06_price']?> KWD' onClick='javascript:addmoney()'>";
           setTimeout(function(){
             $("#playbtn").hide()
             $.ajax({
               type: "POST",
               url: '<?=base_url("../Users/set_timeout")?>',
               data: {time:totalwatch, id: '<?=$vid['06_id'];?>', type: '<?=$vid['05_type'];?>'},
               success: function(data){
                 var message = "You missed clicking pay me button...";
                 $('#message').html(message);
                 $( "#ex1" ).modal();
                   setTimeout(function(){
                     window.location.href = "<?=base_url('../Users/treasure')?>";
                   }, 2000);
               }
             });
           }, 10000);
           return false;
        }
    }
    var done = false;
    function onPlayerStateChange(event) {
        if ((event.data==YT.PlayerState.PLAYING)&&(dorun==0)&&(doend==0)){
           dorun=1;
           myinterval=setInterval(decduration,1000);
        }
        else if(event.data==YT.PlayerState.PAUSED){
            dorun=0;
            $.ajax({
               type: "POST",
               url: '<?=base_url("../Users/set_timeout")?>',
               data: {time:totalwatch, id: '<?=$vid['06_id'];?>', type: '<?=$vid['05_type'];?>'},
               success: function(data){
                 var message = "Sorry... You paused video in between..";
                 $('#message').html(message);
                 $( "#ex1" ).modal();
                 setTimeout(function(){
                   window.location.href = "<?=base_url('../Users/treasure')?>";
                 }, 5000);
               }
            });
            return false;
        }
    }
    function addmoney(){
        $.ajax({
               type: "POST",
               url: '<?=base_url("../Users/add_money")?>',
               data: {time:totalwatch,type:'<?=$vid['05_type'];?>'},
               success: function(data){
                 if(data == 'true'){
                    var message = "Congratss... Your amount is added to your wallet.";
                    $('#message').html(message);
                    $( "#ex1" ).modal();
                      setTimeout(function(){
                        window.location.href = "<?=base_url('../Users/treasure')?>";
                      }, 5000);
                  }else{
                    var message = "Sorry... We are facing difficulty to add amount in your wallet.";
                      $('#message').html(message);
                      $( "#ex1" ).modal();
                  }
                }
            });
    }    
    window.scrollTo(0,document.body.scrollHeight);

</script>
