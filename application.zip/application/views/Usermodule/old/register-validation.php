<script>
    $("#mobile").blur(function(){
        var mbcheck = $('#mbcheck').val();
        if(mbcheck==0){
            var mobile = $('#mobile').val();
            var mno = /^(?=.*[0-9]).{8}$/;
            if(mobile.match(mno)){ 
                $("#mobile").css("border", "1px solid #ccc");
                $('#mobileerror').html("");
                
                $.ajax({
                    url:'<?=base_url("Users/check_mobile")?>',
                    method: 'post',
                    data: {mobile: mobile},
                    dataType: 'json',
                    success: function(response){
                        if(response===true){
                            $("#mobile").css("border", "1px solid #ccc");
                            $('#motp').css("display", "block");
                            $('#mobileerror').html("");
                            $('#mbcheck').val("0");
                        }
                        else{
                            $("#mobile").css("border", "1px solid red");
                            $('#mobileerror').html("Mobile Number already registered.");
                            $('#mbcheck').val("0");
                        }
                    }
                });
            }
            else{
                $("#mobile").css("border", "1px solid red");
                $('#mobileerror').html("Mobile Number Should be 8 Digit Only");
            }
        }
    });
    
    $("#motp").blur(function(){
        var otp = $('#motp').val();
        var mobile = $('#mobile').val();
            $.ajax({
                url:'<?=base_url("Users/check_otp")?>',
                method: 'post',
                data: {otp: otp, mobile:mobile},
                dataType: 'json',
                success: function(response){
                    if(response===true){
                        $("#motp").css("border", "1px solid #ccc");
                        $("#mobile").attr("readonly", "true");
                        $('#motp').css("display", "none");
                        $('#motp').removeAttr('required');
                        $('#mbcheck').val(1);
                        $('#mobileerror').html("");
                    }
                    else{
                        $("#motp").css("border", "1px solid red");
                        $('#mobileerror').html("Otp Doesn't Match");
                        $('#mbcheck').val("0");
                    }
                }
            });
    });
    
    
    $("#email").blur(function(){
        var emcheck = $('#emcheck').val();
        if(emcheck==0){
            var email = $('#email').val();
            var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
            if(email.match(regex)){ 
                $.ajax({
                    url:'<?=base_url("Users/check_email")?>',
                    method: 'post',
                    data: {email:email},
                    dataType: 'json',
                    success: function(response){
                        if(response===true){
                            $('#eotp').css("display", "block");
                            $("#email").css("border", "1px solid #ccc");
                            $('#emailerror').html("");
                        }
                        else{
                            $("#email").css("border", "1px solid red");
                            $('#emailerror').html("Email Already Registered");
                        }
                    }
                });
            }
            else{
                $("#email").css("border", "1px solid red");
                $('#emailerror').html("Incorrect Email");
            }
        }
    });
    
    $("#eotp").blur(function(){
        var otp = $('#eotp').val();
        var email = $('#email').val();
            $.ajax({
                url:'<?=base_url("Users/check_otp")?>',
                method: 'post',
                data: {otp: otp, mobile:email},
                dataType: 'json',
                success: function(response){
                    if(response===true){
                        $("#email").attr("readonly", "true");
                        $('#eotp').css("display", "none");
                        $('#eotp').removeAttr('required');
                        $('#emcheck').val(1);
                        $('#emailerror').html("");
                    }
                    else{
                        $("#eotp").css("border", "1px solid red");
                        $('#emailerror').html("Otp Doesn't Match");
                        $('#emcheck').val("0");
                    }
                }
            });
        
    });
    
    $('#tdate').blur(function(){
        var dob = $('#tdate').val();
        if(dob!==''){ 
            $("#tdate").css("border", "1px solid #ccc");
            $('#doberror').html("");
            $('#dobcheck').val("1");
        }
        else{
            $("#tdate").css("border", "1px solid red");
            $('#doberror').html("Please enter your date of birth");
            $('#dobcheck').val("0");
        }
    });
    
    $('#referral').blur(function(){
        var referral = $('#referral').val();
        if(referral!==''){
            $.ajax({
                url:'<?=base_url("Users/check_referral")?>',
                method: 'post',
                data: {referral: referral},
                dataType: 'json',
                success: function(response){
                    if(response>0){
                            $("#referral").css("border", "1px solid #ccc");
                            $('#referralerror').html("");
                            $('#referralid').val(response);
                    }else{
                        $("#referral").css("border", "1px solid red");
                        $('#referralerror').html("Invalid referral code");
                    }
                }
            }); 
        }
        else{
            $("#referral").css("border", "1px solid #ccc");
            $('#referralerror').html("");
        }
    });
    $('#password').blur(function(){
        var password = $('#password').val();
        var passw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,12}$/;
        if(password.match(passw)){ 
            $("#password").css("border", "1px solid #ccc");
            $('#passworderror').html("");
            $('#pwcheck').val("1");
        }
        else{
            $("#password").css("border", "1px solid red");
            $('#passworderror').html("Password should be minimum of 8 characters includes<br>One Capital Letter <br>One Small Letter <br> One Numeric Digit");
            $('#pwcheck').val("0");
        }
    });
        
    $('#submit').click(function(e) {
        var mbcheck = $('#mbcheck').val();
        var pwcheck = $('#pwcheck').val();
        var rpwcheck = $('#rpwcheck').val();
        var dobcheck = $('#dobcheck').val();
        var nationality = $('#nationality').val();
        var language = $('#language').val();
        var interest = $('#interest').val();
        var gender = $('#gender').val();
        if(nationality===null){
            $('#nationalityerror').html("Please select nationality");
            $("#nationality").css("border", "1px solid red");
            e.preventDefault();
        }
        else if(nationality!==null){
            $('#nationalityerror').html("");
            $("#nationality").css("border", "1px solid #ccc");
            if(gender===null){
                $('#gendererror').html("Please select gender");
                $("#gender").css("border", "1px solid red");
                e.preventDefault();
            }else{
                $('#gendererror').html("");
                $("#gender").css("border", "1px solid #ccc");  
                if(interest==''){
                    $('#interesterror').html("Please select your interest");
                    $("#interest").css("border", "1px solid red");
                    e.preventDefault();
                }else{
                    $('#interesterror').html("");
                    $("#interest").css("border", "1px solid #ccc");
                    if(language===null){
                        $('#languageerror').html("Please select preferred language");
                        $("#language").css("border", "1px solid red");
                        e.preventDefault();
                    }else{
                        $('#languageerror').html("");
                        $("#language").css("border", "1px solid #ccc");
                        if(mbcheck==1 && rpwcheck==1 && pwcheck==1 && dobcheck==1){
                            return true;
                        }else{
                            e.preventDefault();
                            return false;
                        }
                    }
                }
            }
        }
    });
</script>