<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="description" content="Adzjar Delivering beyond expectation">
  <meta name="author" content="">
  <title>Adzjar | Delivering beyond expectation</title>
  <!-- Mobile Specific Meta-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="<?=base_url('images/favicon.png');?>" />
  <!-- Themefisher Icon font -->
  <link rel="stylesheet" href="<?=base_url('user-assets/plugins/themefisher-font/style.css');?>">
  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="<?=base_url('user-assets/plugins/bootstrap/css/bootstrap.min.css');?>">
  <!-- Revolution Slider -->
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/fonts/font-awesome/css/font-awesome.css');?>">
  <!-- REVOLUTION STYLE SHEETS -->
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/settings.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/layers.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/navigation.css');?>">
  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="<?=base_url('user-assets/css/style.css');?>">
</head>
<body id="body">

<section class="signin-page account">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="block text-center">
          <a class="logo" href="<?=base_url('Users/index');?>">
            <h3>Adzjar</h3>
          </a>
          <p>Change Your Password</p>
            <?php if(isset($_GET['error'])) { ?>
            <div class="alert alert-danger">
                <?php echo $_GET['error']; ?>
            </div>
            <?php } ?>
            <?php if($this->session->flashdata('error') !== null) { ?>
            <div class="alert alert-danger">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
        <?php } ?>
          <form class="text-left clearfix" action="<?=base_url('Users/update_password');?>" method="POST">
              <div class="form-group">
                <input type="email" class="form-control"  placeholder="Email Id" id="email" name="email" value ="<?=$user['01_email'];?>" readonly>
            </div>
            <div class="form-group">
              <input type="password" class="form-control"  placeholder="Password" id="password" name="password" required>
              <div style="color:red;font-size:10px" id="passworderror"></div>
              <input type="hidden" value="0" id="pwcheck">
            </div>
            
            <div class="form-group">
              <input type="password" class="form-control"  placeholder="Confirm Password" id="cpassword" name="cpassword" required>
              <div style="color:red;font-size:10px" id="cpasserror"></div>
              <input type="hidden" value="0" id="rpwcheck">
            </div>
            <div class="text-center">
              <input type="submit" class="btn btn-main text-center" value="Continue" id="submit">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
    <!-- Essential Scripts-->
    
    <!-- Main jQuery -->
    <script src="<?=base_url('user-assets/plugins/jquery/dist/jquery.min.js');?>"></script>
    <!-- Bootstrap 3.1 -->
    <script src="<?=base_url('user-assets/plugins/bootstrap/js/bootstrap.min.js');?>"></script>
    <!-- Bootstrap Touchpin -->
    <script src="<?=base_url('user-assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js');?>"></script>
    <!-- Instagram Feed Js -->
    <script src="<?=base_url('user-assets/plugins/instafeed-js/instafeed.min.js');?>"></script>
    <!-- Video Lightbox Plugin -->
    <script src="<?=base_url('user-assets/plugins/ekko-lightbox/dist/ekko-lightbox.min.js');?>"></script>
    <!-- Count Down Js -->
    <script src="<?=base_url('user-assets/plugins/SyoTimer/build/jquery.syotimer.min.js');?>"></script>
    <!-- Revolution Slider -->
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/jquery.themepunch.tools.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/jquery.themepunch.revolution.min.js');?>"></script>
    <!-- Revolution Slider -->
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.actions.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.carousel.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.kenburn.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.layeranimation.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.migration.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.navigation.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.parallax.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.slideanims.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.video.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.video.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/assets/warning.js');?>"></script>  
    <!-- Google Mapl -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/google-map/gmap.js');?>"></script>
    <!-- Main Js File -->
    <script src="<?=base_url('user-assets/js/script.js');?>"></script>
  </body>
  
  
  <script>
  
  $('#password').blur(function(){
        var password = $('#password').val();
        var passw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,12}$/;
        if(password.match(passw)){ 
            $("#password").css("border", "1px solid #ccc");
            $('#passworderror').html("");
            $('#pwcheck').val("1");
        }
        else{
            $("#password").css("border", "1px solid red");
            $('#passworderror').html("Password should be minimum of 8 characters includes<br>One Capital Letter <br>One Small Letter <br> One Numeric Digit");
            $('#pwcheck').val("0");
        }
    });
    $('#cpassword').blur(function(){
        var pass = $('#password').val();
        var cpass = $('#cpassword').val();
        if(pass!=cpass){
            $('#cpasserror').html("Password Doesn't Match...");
            $('#rpwcheck').val(0);
        }
        else{
            $('#cpasserror').html('');
    	    $('#rpwcheck').val(1);
    	}
    });
    $('#submit').click(function(e) {
        var pwcheck = $('#pwcheck').val();
        var rpwcheck = $('#rpwcheck').val();
        if(rpwcheck==1 && pwcheck==1){
            return true;
        }else{
            e.preventDefault();
            return false;
        }
    });
    </script>
  </html>