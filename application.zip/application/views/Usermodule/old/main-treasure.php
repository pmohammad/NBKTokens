<section class="section">
	<div class="container" style="width:100%;padding:5px;">
	        <div class="row" style="margin-right:0px">
    		    <div class="col-md-3" style="width:15%; float:left">
    		        <img src="<?=base_url('user-assets/images/ads/1.png');?>" style="height:auto;width:95%;margin-left:15px">
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" controls="0" allow="accelerometer; encrypted-media; gyroscope;" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" controls="0" allow="accelerometer; encrypted-media; gyroscope;" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3" style="width:15%;">
    		        <img src="<?=base_url('user-assets/images/ads/1.png');?>" style="height:auto;width:95%;margin-left:15px">
    		    </div>
    		    <div class="col-md-3" style="width:15%; float:left">
    		        <img src="<?=base_url('user-assets/images/ads/1.png');?>" style="height:auto;width:95%;margin-left:15px">
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" controls="0" allow="accelerometer; encrypted-media; gyroscope;" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" controls="0" allow="accelerometer; encrypted-media; gyroscope;" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3" style="width:15%;">
    		        <img src="<?=base_url('user-assets/images/ads/1.png');?>" style="height:auto;width:95%;margin-left:15px">
    		    </div>
    		    <div class="col-md-3" style="width:15%; float:left">
    		        <img src="<?=base_url('user-assets/images/ads/1.png');?>" style="height:auto;width:95%;margin-left:15px">
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" controls="0" allow="accelerometer; encrypted-media; gyroscope;" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3">
    		        <iframe src="https://www.youtube.com/embed/Pz4zHnoib9Q?controls=0" frameborder="0" controls="0" allow="accelerometer; encrypted-media; gyroscope;" allowfullscreen></iframe>
    		    </div>
    		    <div class="col-md-3" style="width:15%;">
    		        <img src="<?=base_url('user-assets/images/ads/1.png');?>" style="height:auto;width:95%;margin-left:15px">
    		    </div>
    		 </div>
        </div>
    </section>