<? require_once('header.php');?>
<body id="body">
<section class="user-dashboard page-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="list-inline dashboard-menu text-center">
					<li><a href="<?=base_url('Users/dashboard');?>">Wallet</a></li>
					<li><a class="active" href="<?=base_url('Users/profile_details');?>">Profile Details</a></li>
				</ul>
        <div class="dashboard-wrapper dashboard-user-profile">
          <div class="media">
            <div class="media-body">
              <ul class="user-profile-list">
                <?foreach($user as $key){?>
                    <li><span>Full Name :</span><?=$key['01_name'];?></li>
                    <li><span>Country :</span><?=$key['08_nationality'];?></li>
                    <li><span>Email :</span><?=$key['01_email'];?></li>
                    <li><span>Phone :</span><?="+965".$key['01_mobile'];?></li>
                    <li><span>Referral Link :</span>
                    <? $link = urlencode('http://adzjar.com/test/Users/register?referral='.$key['01_referring_code']);?>
                        <a href='https://api.whatsapp.com/send?phone=&text=<?=$link?>' style="padding: 10px;" target="_blank">
							<i class="tf-ion-social-whatsapp"></i>
						</a>
					</li>
                    <li><span>Total Referral :</span><?=$key['01_total_refer'];?></li>
                    <?if($key['01_total_refer']>0){?>
                        <th><button class="btn btn-info btn-sm">Withdraw</button></th>
                    <?}?>
                <?}?>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<? require_once('footer.php');?>