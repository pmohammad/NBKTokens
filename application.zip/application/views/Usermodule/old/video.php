<?require_once('header2.php');?>
<style>
    .container{
        width:100%;
    }
    .adsbanner{
        width:15%;
        display:block;
    }
    span{
        display: inline-block;
        list-style-type: none;
        text-transform: uppercase;
        color: #1abc9c;
        font-family: sans-serif;
        font-weight: 500;
        font-size:1.5rem;
        float:right;
        padding-right:85px;
        padding-top:5px;
    }
    #player{
        width:760px;
        height:520px;
        display:block;
        margin-right:auto;
        margin-left:auto;
    }
    @media (max-width: 767px){
        #player{
            width:100%;
            height:250px;
        }
        span{
            padding-right:0px;
        }
        .adsbanner{
            width:100%;
            display:flex;
        }
    }
    .product-item{
        margin-bottom:10px;
    }
    
</style>
<div>
    <img src="<?=base_url('../user-assets/images/banner/banner.png');?>"style="height:70%;width:100%;">
</div>


<section class="products section bg-gray" style="padding: 0px;">
	<div class="container">
		<div class="row">
			<div class="title text-center" style="padding: 0px;">
				<h2>You will make KWD <?=$vid['06_price'];?> </h2>
				<h5>(Don't Close in Between)</h5>
			</div>
		</div>
		<div class="row">
		    <div class="col-md-2 col-sm-6 adsbanner" style="float:left">
		        <div class="product-item">
		            <img class="img-responsive" src="<?=base_url('../user-assets/images/ads/1.png');?>" alt="product-img" />
        		</div>
        		<div class="product-item">
		            <img class="img-responsive" src="<?=base_url('../user-assets/images/ads/2.png');?>" alt="product-img" />
        		</div>
        		<div class="product-item">
		            <img class="img-responsive" src="<?=base_url('../user-assets/images/ads/3.png');?>" alt="product-img" />
        		</div>
		    </div>
		    
		    <div class="col-md-8 col-sm-6">
		        
		        <div id="player"></div>
		        <span id="seconds"></span>
        		<div id="playbtn"></div>
		    </div>
		    <div class="col-md-2 col-sm-6 adsbanner" style="float:right;">
		        <div class="product-item">
		            <img class="img-responsive" src="<?=base_url('../user-assets/images/ads/1.png');?>" alt="product-img" />
        		</div>
        		<div class="product-item">
		            <img class="img-responsive" src="<?=base_url('../user-assets/images/ads/2.png');?>" alt="product-img" />
        		</div>
        		<div class="product-item">
		            <img class="img-responsive" src="<?=base_url('../user-assets/images/ads/3.png');?>" alt="product-img" />
        		</div>
		    </div>
		</div>
		
	</div>
</section>

<?require_once('footer2.php');
$S = $vid['05_seconds'];
?>
<script>
var dorun=0;
 var duration=<?=$S;?>;
 var doend=0;
 totalwatch = 0;
 var myinterval;
      var tag = document.createElement('script');

      tag.src = "https://www.youtube.com/iframe_api";
      var firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
      var player;
    function onYouTubeIframeAPIReady() {
        player = new YT.Player('player', {
          videoId: '<?=$vid['05_link']?>',
          width:'760',
          height:'515',
          playerVars: {
             color: 'white',
             controls: '0',
             autoplay: '1',
             disablekb:'1',
             rel:      '0',
             showinfo: '0',
          },
          events: {
            'onReady': initialize,
            'onStateChange': onPlayerStateChange
          }
        });
    }
    function initialize(){
        updateTimerDisplay();
        updateProgressBar();
        clearInterval(time_update_interval);
        time_update_interval = setInterval(function(){
            updateTimerDisplay();
            updateProgressBar();
        }, 1000)
    }
    function startvideo(){
        player.playVideo();
    }
    function decduration(){
        duration=duration-1;
        totalwatch = totalwatch+1;
        document.getElementById("seconds").innerHTML=duration+" S";
        if (duration<=0){
           doend=1;
           clearInterval(myinterval);
           //alert('done');
           document.getElementById("playbtn").innerHTML="<input type='button' style='width:250px;height:40px;font-size:22px;font-weight:bold;margin: 15px;display: block;margin-right: auto;margin-left: auto;' value='ENROLL $ 5.00' onClick='javascript:addmoney()'>";
           setTimeout(function() {
        $("#playbtn").hide()
        $.ajax({
               type: "POST",
               url: '<?=base_url("../Users/set_timeout")?>',
               data: {time:totalwatch}, 
               success: function(data){
                   window.location.href = "http://adzjar.com/Users/treasure";
               }
            }); 
        window.location.href = "http://adzjar.com/Users/treasure";
    }, 10000);
           return false;
        }
    }
    var done = false;
    function onPlayerStateChange(event) {
        if ((event.data==YT.PlayerState.PLAYING)&&(dorun==0)){
           dorun=1;
           myinterval=setInterval(decduration,1000);
           $.get("startshow.php?vid=861").done(function(json){
           });
        }
        if (event.data==YT.PlayerState.PAUSED){
            $.ajax({
               type: "POST",
               url: '<?=base_url("../Users/set_timeout")?>',
               data: {time:totalwatch}, 
               success: function(data){
                   window.location.href = "http://adzjar.com/Users/treasure";
               }
            }); 
            
            return false;
        }
    }
    function addmoney(){
        $.ajax({
               type: "POST",
               url: '<?=base_url("../Users/add_money")?>',
               data: {time:totalwatch}, 
               success: function(data){
                   alert('Congrats...Amount Added')
                   window.location.href = "http://adzjar.com/Users/treasure";
               }
            });
    }
    </script>