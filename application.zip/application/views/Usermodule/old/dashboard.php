<? require_once('header.php');?>
<body id="body">
<section class="user-dashboard page-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="list-inline dashboard-menu text-center">
					<li><a class="active" href="<?=base_url('Users/dashboard');?>">Wallet</a></li>
					<li><a href="<?=base_url('Users/profile_details');?>">Profile Details</a></li>
				</ul>
				<?if($this->session->flashdata('error') !== null) { ?>
                    <div class="alert alert-danger">
                        <?=$this->session->flashdata('error'); ?>
                    </div>
                <?}
                if($this->session->flashdata('message') !== null) { ?>
                    <div class="alert alert-success">
                        <?=$this->session->flashdata('message'); ?>
                    </div>
                <?}?>
                  <a style="float: right;margin-left: 10px;" href="#" data-toggle="tooltip" title="Conditions:Minimum 3 Referrals and 50 Kd amount should be there for withdrawal"><i class="tf-ion-information-circled"></i></a>
                <button class="btn btn-success" <?if(($balance['01_total_refer']<3) || ($balance['09_balance']<50)){?>disabled = 'disabled' title="Please refer at least one to withdraw amount"<?}?> style="float: right;margin-bottom: 20px;" id="withdraw">Withdraw - <?=$balance['09_balance'];?></button>
						<table class="table">
							<thead>
								<tr>
									<th>Date</th>
									<th>Description</th>
									<th>Expire in</th>
									<th>Earning</th>
									<th>Withdrawal</th>
									<th>Balance</th>
								</tr>
							</thead>
							<tbody>
							    <?$i=1;foreach($wallet as $key){?>
								<tr>
									<td><?=date("Y-m-d",strtotime($key['09_date']));?></td>
									<td><?=$key['09_description'];?></td>
									<td><?echo date("Y-m-d", strtotime("+364 days", strtotime($key['09_date'])));?></td>
									<td><span class="label label-success"><?if($key['09_earn']>0) echo $key['09_earn'];?></span></td>
									<td><span class="label label-danger"><?if($key['09_withdraw']>0) echo $key['09_withdraw'];?></span></td>
									<td><?=$key['09_balance'];?></td>
								</tr>
								<?}?>
							</tbody>
						</table>
					</div>
			</div>
		</div>
	</div>
</section>
			</div>
		</div>
	</div>
</section>


<div class="modal fade" id="bankdetails" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Your Bank Details To Withdraw </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="<?php echo base_url('Users/update_bankdetails'); ?>" autocomplete="off" enctype="multipart/form-data" id="submit">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Account Name</label>
                            <input class="form-control form-control-lg" name="acc_name" id="acc_name" type="text" required placeholder="Bank Account Name" >
                        </div>
                        <div class="form-group">
                            <label>Select Bank</label>
                            <select class="form-control form-control-lg" name="banks" id="banks">
                                <option diabled value="default">Select Bank</option>
                                <?foreach($banks as $key){?>
                                    <option value="<?=$key['bank_id'];?>"><?=$key['name'];?></option>
                                <?}?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Civil ID (Front)</label>
                            <input class="form-control form-control-lg" name="civil_front" id="civil_front" type="file" required>
                        </div>
                        <div class="form-group">
                            <label>Civil Id (Back)</label>
                            <input class="form-control form-control-lg" id="civil_back" name="civil_back" type="file" required>
                        </div>
                        <div class="form-group">
                            <label>IBAN</label>
                            <input class="form-control form-control-lg" id="hash" name="hash" type="text" placeholder="IBAN" required autocomplete="off">
                            <input id="id" name="id" type="text" hidden value='<?=$balance['01_id']?>'>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Please Proceed</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    
<div class="modal fade" id="otpmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Your Bank Details To Withdraw </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="post" action="<?php echo base_url('Users/request_withdraw'); ?>" autocomplete="off" >
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Account Password</label>
                            <input class="form-control form-control-lg" id="hash" name="hash" type="password" placeholder="Your Account Password" required autocomplete="off">
                            <input id="id" name="id" type="text" hidden value='<?=$balance['01_id']?>'>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Please Proceed</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <? require_once('footer.php');?>
    
<script>
    $('#withdraw').click(function(){
        var bank = '<?=$balance['is_bank_details']?>';
        if(bank==0){
            $('#bankdetails').modal('show');
        }else{
            $('#otpmodal').modal('show');
        }
    });
</script>    
<script>
    $('#submit').click(function(e) {
        var bank = $('#banks').val();
        if(bank=="default"){
            e.preventDefault();
        }else{
            return true;
        }
    });
</script>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});
</script>
    
    
