<?require_once('header.php');?>
<style>
    .col-sm-6{
        width:23%;
        display:inline-block;
        padding-right:5px;
        padding-left:5px;
    }
    .container{
        width:100%;
    }
    .adsbanner{
        width:15%;
        display:block;
    }
    #loadmore{
        display:block;
        margin-right:auto;
        margin-left:auto;
        margin-bottom:10px;
        border:2px solid #000;
        color:#000;
    }
    #loadmore:hover{
        transition: all 0.4s cubic-bezier(.86,.31,.55,.99);
        background:white;
        font-size:18px;
    }
    .price{
        text-align:center;
        padding-top:7px;
    }
    @media (max-width: 767px){
        .adsbanner{
            display:none;
        }
        .col-sm-6{
            width:32.7%;
        }
    }
</style>
<? if($this->session->flashdata('error') !== null) { ?>
        <div class="alert alert-danger">
            <? echo $this->session->flashdata('error'); ?>
        </div>
        <? } ?>
<div>
    <img src="<?=base_url('user-assets/images/banner/banner.png');?>"style="height:70%;width:100%;">
</div>

<section class="products section bg-gray" style="padding: 0px;">
	<div class="container">
		<div class="row">
			<div class="title text-center" style="padding: 0px;">
				<h2>Advertisements </h2>
				<h5>(Click To Watch Videos)</h5>
			</div>
		</div>
    	<div class="row">
    		<div class="col-md-4 col-sm-6 adsbanner" style="float:left">
    		    <div class="product-item">
    		        <img class="img-responsive" src="<?=base_url('user-assets/images/banner/ads-1.png');?>" alt="product-img" />
            	</div>
    		</div>
    		<div class="col-md-4 col-sm-6 adsbanner" style="float:right;">
    		    <div class="product-item">
    		        <img class="img-responsive" src="<?=base_url('user-assets/images/banner/ads-1.png');?>" alt="product-img" />
    		    </div>
    		</div>
    		    <?foreach($treasure as $key){?>
    			<div class="col-md-4 col-sm-6">
    			    <a href="<?=base_url('Users/video/').$key['05_id']."/".$key['06_id'];?>">
        				<div class="product-item">
        					<img class="img-responsive" src="<?=base_url($key['05_thumbnail']);?>" alt="product-img" />
        				    <div class="product-content" style="border: 1px solid #ccc;">
        					    <p class="price"><?=$key['06_price'];?></p>
        				    </div>
        			    </div>
        		    </a>
    			</div>
			<?}?>
		</div>
		<a href="<?=base_url('../Users/treasure/'. $page);?>" id="loadmore" class="btn btn-outline btn-sm">Load More</a>
	</div>
</section>

<?require_once('footer.php');?>
