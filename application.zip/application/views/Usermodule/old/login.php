<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="description" content="Adzjar Delivering beyond expectation">
  <meta name="author" content="">
  <title>Adzjar | Delivering beyond expectation</title>
  <!-- Mobile Specific Meta-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="<?=base_url('images/favicon.png');?>" />
  <!-- Themefisher Icon font -->
  <link rel="stylesheet" href="<?=base_url('user-assets/plugins/themefisher-font/style.css');?>">
  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="<?=base_url('user-assets/plugins/bootstrap/css/bootstrap.min.css');?>">
  <!-- Revolution Slider -->
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/fonts/font-awesome/css/font-awesome.css');?>">
  <!-- REVOLUTION STYLE SHEETS -->
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/settings.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/layers.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/navigation.css');?>">
  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="<?=base_url('user-assets/css/style.css');?>">
</head>
<body id="body">

<section class="signin-page account">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="block text-center">
          <a class="logo" href="<?=base_url('Users/index');?>">
            <h3>Adzjar</h3>
          </a>
          <h2 class="text-center">Welcome Back</h2>
            <? if(isset($_GET['error'])) { ?>
            <div class="alert alert-danger">
                <? echo $_GET['error']; ?>
            </div>
            <? }
            if($this->session->flashdata('message') !== null) { ?>
                <div class="alert alert-success">
                    <?=$this->session->flashdata('message'); ?>
                </div>
            <?}
            if($this->session->flashdata('error') !== null) { ?>
                <div class="alert alert-danger">
                    <?=$this->session->flashdata('error'); ?>
                </div>
            <?}?>
          <form class="text-left clearfix" action="<?=base_url('Users/login');?>" method="POST">
            <div class="form-group">
              <input type="text" readonly  value="+965" disabled style="width:15%;border:1px solid #ccc;text-align:center">
            <input type="tel" class="form-control"  placeholder="Mobile Number" id="mobile" name="mobile" required style="width:85%;float:right">
            </div>
            <div class="form-group">
              <input type="password" class="form-control" placeholder="Password" name="password">
            </div>
            <div class="text-center">
              <p style="text-align: right;"><a href="<?=base_url('Users/forgot_password');?>">Forgot Password ?</a></p>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-main text-center" >Login</button>
            </div>
          </form>
          <p class="mt-20">New in this site ?<a href="<?=base_url('Users/register');?>"> Create New Account</a></p>
        </div>
      </div>
    </div>
  </div>
</section>
    <!-- Essential Scripts-->
    
    <!-- Main jQuery -->
    <script src="<?=base_url('user-assets/plugins/jquery/dist/jquery.min.js');?>"></script>
    <!-- Bootstrap 3.1 -->
    <script src="<?=base_url('user-assets/plugins/bootstrap/js/bootstrap.min.js');?>"></script>
    <!-- Bootstrap Touchpin -->
    <script src="<?=base_url('user-assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js');?>"></script>
    <!-- Instagram Feed Js -->
    <script src="<?=base_url('user-assets/plugins/instafeed-js/instafeed.min.js');?>"></script>
    <!-- Video Lightbox Plugin -->
    <script src="<?=base_url('user-assets/plugins/ekko-lightbox/dist/ekko-lightbox.min.js');?>"></script>
    <!-- Count Down Js -->
    <script src="<?=base_url('user-assets/plugins/SyoTimer/build/jquery.syotimer.min.js');?>"></script>
    <!-- Revolution Slider -->
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/jquery.themepunch.tools.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/jquery.themepunch.revolution.min.js');?>"></script>
    <!-- Revolution Slider -->
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.actions.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.carousel.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.kenburn.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.layeranimation.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.migration.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.navigation.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.parallax.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.slideanims.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.video.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/revolution/js/extensions/revolution.extension.video.min.js');?>"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/revolution-slider/assets/warning.js');?>"></script>  
    <!-- Google Mapl -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCC72vZw-6tGqFyRhhg5CkF2fqfILn2Tsw"></script>
    <script type="text/javascript" src="<?=base_url('user-assets/plugins/google-map/gmap.js');?>"></script>
    <!-- Main Js File -->
    <script src="<?=base_url('user-assets/js/script.js');?>"></script>
  </body>
  </html>