<? require_once('header.php');?>
<body id="body">
<section class="user-dashboard page-wrapper">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="list-inline dashboard-menu text-center">
					<li><a href="<?=base_url('Users/dashboard');?>">Wallet</a></li>
					<li><a class="active" href="<?=base_url('Users/watch_history');?>">Watch History</a></li>
					<li><a href="<?=base_url('Users/profile_details');?>">Profile Details</a></li>
				</ul>
                <div class="table-responsive" style="margin-top: 40px;margin-bottom: 20px;">
                <table class="table">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Date</th>
                      <th>Video Thumbnail</th>
                      <th>Status</th>
                      <th>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?$i=1;
                      foreach($history as $key){
                      if($key['07_status']==1 && $key['07_pay_me']==0){
                          $status = "Watched But Not clicked Pay Button";
                      }else if($key['07_status']==1 && $key['07_pay_me']==1){
                          $status = "Watched And Earned";
                      }else if($key['07_status']==2 && $key['07_pay_me']==0){
                          $status = "Left In Between";
                      }if($key['07_status']==0 ){
                          $status = "Left In Between";
                      }
                      
                      ?>
                    <tr>
                      <td><?=$i++;?></td>
                      <td><?=$key['07_date'];?></td>
                      <td><img src="<?="../".$key['05_thumbnail'];?>" height="50px" width="50px"></td>
                      <td><?=$status;?></td>
                      <td><?=$key['07_amount'];?></td>
                    
                    </tr>
                      <?}?>
                    
                  </tbody>
                </table>
          </div>
            </div>
        </div>
    </div>
</section>

<? require_once('footer.php');?>