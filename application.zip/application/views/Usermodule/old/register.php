<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="description" content="Adzjar Delivering beyond expectation">
  <meta name="author" content="">
  <title>Adzjar | Delivering beyond expectation</title>
  <!-- Mobile Specific Meta-->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicon -->
  <link rel="shortcut icon" type="image/x-icon" href="<?=base_url('images/favicon.png');?>" />
  <!-- Themefisher Icon font -->
  <link rel="stylesheet" href="<?=base_url('user-assets/plugins/themefisher-font/style.css');?>">
  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="<?=base_url('user-assets/plugins/bootstrap/css/bootstrap.min.css');?>">
  <!-- Revolution Slider -->
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/fonts/font-awesome/css/font-awesome.css');?>">
  <!-- REVOLUTION STYLE SHEETS -->
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/settings.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/layers.css');?>">
  <link rel="stylesheet" type="text/css" href="<?=base_url('user-assets/plugins/revolution-slider/revolution/css/navigation.css');?>">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="<?=base_url('user-assets/css/style.css');?>">
  <style>
    input[type="date"]:before {
        content: attr(placeholder) !important;
    }

  </style>
</head>
<body id="body">

<section class="signin-page account">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="block text-center" style="padding:10px;margin:10px 0">
          <a class="logo" href="<?=base_url('Users/index');?>">
            <h3>Adzjar</h3>
          </a>
          <h2 class="text-center">Create Your Account</h2>
          <? if(validation_errors() !== '') { ?>
        <div class="alert alert-danger">
            <? echo validation_errors(); ?>
        </div>
        <? } ?>
        <? if($this->session->flashdata('message') !== null) { ?>
        <div class="alert alert-success">
            <? echo $this->session->flashdata('message'); ?>
        </div>
        <? } ?>
        <? if($this->session->flashdata('error') !== null) { ?>
        <div class="alert alert-danger">
            <? echo $this->session->flashdata('error'); ?>
        </div>
        <? } ?>
          <form class="text-left clearfix" action="<?=base_url('Users/registration');?>" method="POST" id="registerform">
            <div class="form-group">
              <input type="text" class="form-control"  placeholder="Name" id="name" name="name" required>
            </div>
            <div class="form-group">
                <input type="text" readonly  value="+965" disabled style="width:15%;border:1px solid #ccc;text-align:center">
                <input type="tel" class="form-control"  placeholder="Mobile Number" id="mobile" name="mobile" required style="width:85%;float:right" required>
                <input type="text"  inputmode="numeric" class="form-control"  placeholder="Enter OTP to verify" id="motp" name="motp" style="width:55%;float:right;margin:15px;display:none" required>
                <div style="color:red;" id="mobileerror"></div>
                <input type="hidden" value="0" id="mbcheck">
            </div>
            <div class="form-group">
              <input type="email" class="form-control"  placeholder="Email Id" id="email" name="email">
              <input type="text"  inputmode="numeric" class="form-control"  placeholder="Enter OTP to verify" id="eotp" name="eotp" style="width:55%;float:right;margin:15px;display:none" required>
              <div style="color:red;" id="emailerror"></div>
                <input type="hidden" value="0" id="emcheck">
            </div>
            <div class="form-group">
              <select name="nationality" class="form-control" id="nationality" required>
                  <option selected disabled>Select Nationality</option>
                  <?foreach($nationality as $key){?>
                    <option value="<?=$key['08_id'];?>"><?=$key['08_nationality'];?></option>
                  <?}?>
              </select>
              <div style="color:red" id="nationalityerror"></div>
            </div>
            
            <div class="form-group">
              <select name="language" class="form-control" id="language" required>
                  <option selected disabled>Select Language</option>
                  <?foreach($language as $key){?>
                    <option value="<?=$key['11_id'];?>"><?=$key['11_language'];?></option>
                  <?}?>
              </select>
              <div style="color:red" id="languageerror"></div>
            </div>
            
            <div class="form-group">
              <div id="datepicker1" class="input-group date" data-date-format="yyyy-mm-dd">
                  <input class="form-control" type="text" readonly name="tdate" id="tdate" placeholder="Date Of Birth" style="background:#fff" />
                  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                </div>
                <div style="color:red;" id="doberror"></div>
                <input type="hidden" value="0" id="dobcheck">
            </div>
            <div class="form-group">
              <select name="gender" class="form-control" id="gender" required>
                  <option selected disabled>Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
              </select>
              <div style="color:red" id="gendererror"></div>
            </div>
            <div class="form-group">
              <select name="interest[]" class="form-control" id="interest" required multiple>
                  <option selected disabled>In what you are interested?</option>
                  <?foreach($interest as $key){?>
                    <option value="<?=$key['10_id'];?>"><?=$key['10_interest'];?></option>
                  <?}?>
              </select>
              <div style="color:red" id="interesterror"></div>
            </div>
            <?if(isset($_GET['referral'])){
                $referral = $_GET['referral'];
            }
            else{
                $referral = '';
            }
            ?>
            <div class="form-group">
              <input type="text" readonly class="form-control"  placeholder="Referral Code" id="referral" name="referral" value="<?=$referral;?>">
              <div style="color:red;" id="referralerror"></div>
              <input type="hidden" class="form-control"  id="referralid" name="referralid" value="0">
            </div>
            <div class="form-group">
              <input type="password" class="form-control"  placeholder="Password" id="password" name="password" required>
              <div style="color:red;font-size:10px" id="passworderror"></div>
              <input type="hidden" value="0" id="pwcheck">
            </div>
            
            <div class="form-group">
              <input type="password" class="form-control"  placeholder="Confirm Password" id="cpassword" name="cpassword" required>
              <div style="color:red;font-size:10px" id="cpasserror"></div>
              <input type="hidden" value="0" id="rpwcheck">
            </div>
            
            
            <div class="text-center">
              <input type="submit" class="btn btn-main text-center" value="Sign In" id="submit">
            </div>
          </form>
          <p class="mt-20">Already hava an account ?<a href="<?=base_url('Users/index');?>"> Login</a></p>
          <!--<p><a href="forget-password.html"> Forgot your password?</a></p>-->
        </div>
      </div>
    </div>
  </div>
</section>

    <?require_once('footer.php');?>
    <?require_once('register-validation.php');?>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
       <script type="text/javascript">
            $(function () {
                $("#datepicker1").datepicker({ 
                    autoclose: true, 
                    todayHighlight: true,
                    endDate: '-8y',
                }).datepicker('update', new Date());
            });

        </script>
        
    <script>
        $('#cpassword').blur(function(){
            var pass = $('#password').val();
    	    var cpass = $('#cpassword').val();
    	    if(pass!=cpass){
    	        $('#cpasserror').html("Password Doesn't Match...");
    	        $('#rpwcheck').val(0);
    	    }
    	    else{
    	        $('#cpasserror').html('');
    	        $('#rpwcheck').val(1);
    	    }
        });
    </script>

  </body>
  </html>