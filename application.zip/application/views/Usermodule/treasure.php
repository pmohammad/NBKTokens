<?require_once('header.php');?>

<style>
        .active{
            display:block;
        }
        .inactive{
            display:none;
        }
    </style>
<div class="main-content d-flex flex-row">
      <div class="main-container">
        <div class="main-header">
          <h1>Welcome back <?$name = explode(' ', $this->session->uname); echo $name[0];?></h1>
          <p>Click to Watch Videos</p>
        </div> <!--/.main-header-->
        <!-- VIDEO LIST -->

        <div class="video-row d-flex flex-row flex-wrap justify-content-between">
            
          <?$i=0;
          if(sizeof($treasure)>0){
              foreach($treasure as $key){?>
                <div class="video-item" data-id="<?=$i;?>">
                  <div class="video-badge">KWD <?=$key['06_price'];?></div>
                  <a href="<?=base_url('Users/video/').$key['05_id']."/".$key['06_id'];?>">
                      <img class="img-responsive" src="<?=base_url($key['05_thumbnail']);?>" alt="product-img" height="100%" width="100%" />
                  </a>
                </div>
    
                <?$i++;
                if($i%3==0){?>
                  <div class="video-banner">
                    <img class="d-none d-xl-block" src="<?=base_url('user-assets/images_temp/video-banner.png');?>" alt="Video Banner">
                    <img class="d-none d-lg-block d-xl-none" src="<?=base_url('user-assets/images_temp/video-banner2.png');?>" alt="Video Banner Tablet">
                    <img class="d-lg-none" src="<?=base_url('user-assets/images_temp/video-banner3.png');?>" alt="Video Banner Mobile">
                  </div> <!--/.video-banner-->
                <?}
            }
        }?>
      </div> <!--/.video-item-->



        <div class="video-list">

          <div class="video-more">
              <?//$this->session->set_userdata('camp_ids',$register['01_age']);?>
              <?$i=0;?>
            <a href="javascript:;" id="show_more" class="video-more__button shadow-sm simple-pagination page-link" onclick="show_more()">Load More</a>
            
            <div class="video-more__line"></div>
          </div> <!--/.video-more-->

        </div> <!--/.video-list-->
        <!-- END VIDEO LIST -->
      </div> <!--/.main-container-->
      <div class="main-banner d-none d-sm-flex">
        <div class="main-banner__wrap">
          <img src="<?=base_url('user-assets/images_temp/main-banner.png');?>" alt="Main Banner">
        </div> <!--/.main-banner__wrap-->
      </div> <!--/.main-banner-->
    </div> <!--/.main-content-->
    
    <div id="pagination-container"></div>
    
<?require_once('footer.php');?>


<script>
        var items = $(".video-item");
        var banners = $(".video-banner");
        var numItems = items.length;
        var numBanners = banners.length;
        var perPage = 9;
        var pageBanners = perPage /3 ;
        pageNumber = 1;
        items.slice(perPage).hide();
        banners.slice(pageBanners).hide();
        $('#pagination-container').pagination({
            items: numItems,
            itemsOnPage: perPage,
            onPageClick: function (pageNumber) {
                var showFrom = perPage * (pageNumber - 1);
                var showTo = showFrom + perPage;
                items.hide().slice(showFrom, showTo).show();
            }
        });
        function show_more(){
            banners.hide();
            var actual = numItems/perPage;
            actual = Math.ceil(actual);
            if(pageNumber<actual){
                pageNumber = pageNumber+1;
                var showFrom = perPage * (pageNumber - 1);
                var showTo = showFrom + perPage;
                items.hide().slice(showFrom, showTo).show();
            }else{
                var message = "You're all caught up...";
                $('#message').html(message);
                $( "#ex1" ).modal();
            }
            
        }
        </script>
