<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>AdzJar - Single Video</title>

  <link rel="canonical" href="https://www.adzjar.com">
  <meta name="title" content="Adz Jar - Static Front-end content">
  <meta name="referrer" content="unsafe-url">
  <meta name="description" content="Adz Jar description">
  <link rel="icon" type="image/x-icon" href="<?=base_url('user-assets/images_temp/logo.svg');?>"  />
  <!-- App CSS -->
  <style>

    html {
      box-sizing: border-box;
    }
    *,
    *::before,
    *::after {
      box-sizing: inherit;
    }
    .validation{
      color: red;
      font-size: 12px;
    }
  </style>
  <link rel="stylesheet" href="<?=base_url('user-assets/css/style.css');?>">
  <link rel="stylesheet" href="<?=base_url('user-assets/css/custom.css');?>">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <main class="main d-flex login-main">

    <div class="login mr-auto mb-auto ml-auto d-flex flex-column align-items-center">
      <!-- LOGIN LOGO -->
      <div class="login-logo" style="margin-top: 1.25rem;">
        <a href="<?=base_url('Users/index');?>">
          <img src="<?=base_url('user-assets/images_temp/logo.svg');?>" alt="Adz Jar Logo">
        </a>
      </div><!--/.login-logo-->
      <!-- END LOGIN LOGO -->
      <!-- LOGIN FORM -->
      <div class="login-card">
        <div class="card shadow-sm">
          <div class="card-header bg-white border-0 p-0">
            <h1>Welcome</h1>
            <p>Please fill the below details !!</p>
          </div> <!--/.card-header-->
          <div class="card-body p-0">
            <form class="login-form" id="registerform" method="post" action="<?=base_url('Users/registration');?>">

              <div class="form-group">
                <input type="text" class="form-control"  placeholder="Full Name" id="name" name="name" required>
              </div> <!--/.form-group-->

              <div class="form-group login-phone d-flex flex-row">
                <div class="login-phone__code mr-2">
                  <input type="text" class="form-control" value="+965" name="phone-prefix" disabled>
                </div> <!--/.login-phone__codee-->

                <div class="login-phone__number">
                  <input type="tel" class="form-control"  placeholder="Mobile Number" id="mobile" name="mobile" required required autocomplete="off">
                <input type="text"  inputmode="numeric" class="form-control"  placeholder="Enter OTP to verify" id="motp" name="motp" style="width:65%;float:right;margin:15px;display:none" required>
                  <div class="validation" id="mobileerror"></div>
                  <input type="hidden" value="0" id="mbcheck">
                </div> <!--/.login-phone__number-->
              </div> <!--/.form-group-->

              <div class="form-group">
                <input type="email" class="form-control"  placeholder="Email Id" id="email" name="email" autocomplete="off">
              <input type="text"  inputmode="numeric" class="form-control"  placeholder="Enter OTP to verify" id="eotp" name="eotp" style="width:55%;float:right;margin:15px;display:none" required>
              <div class="validation" id="emailerror"></div>
                <input type="hidden" value="0" id="emcheck">
              </div> <!--/.form-group-->

              <div class="form-group">
                <select name="nationality" class="form-control" id="nationality" required>
                  <option selected disabled>Select Nationality</option>
                  <?foreach($nationality as $key){?>
                    <option value="<?=$key['08_id'];?>"><?=$key['08_nationality'];?></option>
                  <?}?>
              </select>
                <div class="validation" id="nationalityerror"></div>
              </div> <!--/.form-group-->


              <div class="form-group">
                <select name="language" class="form-control" id="language" required>
                  <option selected disabled>Select Language</option>
                  <?foreach($language as $key){?>
                    <option value="<?=$key['11_id'];?>"><?=$key['11_language'];?></option>
                  <?}?>
              </select>
                <div class="validation" id="languageerror"></div>
              </div> <!--/.form-group-->


            <div class="form-group">
                <div id="datepicker1" class="input-group date" data-date-format="yyyy-mm-dd">
                    <input class="form-control" type="text" readonly name="tdate" id="tdate" placeholder="Date Of Birth" style="background:#fff" />
                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                </div>
                <div class="validation" id="doberror"></div>
                <input type="hidden" value="0" id="dobcheck">
            </div> <!--/.form-group-->


              <div class="form-group">
                <select name="gender" class="form-control" id="gender" required>
                  <option selected disabled>Select Gender</option>
                  <?foreach($gender as $key){?>
                    <option value="<?=$key['14_id'];?>"><?=$key['14_gender'];?></option>
                  <?}?>
              </select>
                <div class="validation" id="gendererror"></div>
              </div> <!--/.form-group-->


              <div class="form-group">
                <select name="interest[]" class="form-control" id="interest" required multiple>
                  <option selected disabled>In what you are interested?</option>
                  <?foreach($interest as $key){?>
                    <option value="<?=$key['10_id'];?>"><?=$key['10_interest'];?></option>
                  <?}?>
              </select>
                <div class="validation" id="interesterror"></div>
              </div> <!--/.form-group-->


              <?if(isset($_GET['referral'])){
                $referral = $_GET['referral'];
              }else{
                  $referral = '';
                }?>

              <div class="form-group">
                <input type="text" readonly class="form-control"  placeholder="Referral Code" id="referral" name="referral" value="<?=$referral;?>">
              <div class="validation" id="referralerror"></div>
              <input type="hidden" class="form-control"  id="referralid" name="referralid" value="0">
              </div> <!--/.form-group-->

              <div class="form-group">
                <input type="password" class="form-control" placeholder="Password" name="password" id="password">
                <div class="validation" id="passworderror"></div>
              <input type="hidden" value="0" id="pwcheck">
              </div> <!--/.form-group-->

              <div class="form-group">
                <input type="password" class="form-control"  placeholder="Confirm Password" id="cpassword" name="cpassword" required>
                <div style="color:red;font-size:10px" id="cpasserror"></div>
                <input type="hidden" value="0" id="rpwcheck">
              </div> <!--/.form-group-->

              <div class="form-group mb-0 login-form__submit">
                <input type="submit" class="btn btn-block btn-danger" value="Register" id="submit">
                <div class="invalid-feedback login-form__error text-center mb-0 mt-2"></div>
              </div> <!--/.form-group-->

            </form> <!--/.login-form-->
          </div> <!--/.card-body-->
        </div>
      </div> <!--/.login-form-->
      <!-- END LOGIN FORM -->
      <!-- LOGIN SINGUP -->
      <div class="login-singup mt-4">
        <p>Have an account? <a href="<?=base_url('Users/index');?>">Click Here</a></p>
      </div> <!--/.login-singup -->
      <!-- END LOGIN SINGUP -->
    </div> <!--/.login-->

  </main> <!--/.main-->
<!-- Optional JavaScript -->



<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

<!-- Core JavaScript -->
<script src="<?=base_url('user-assets/third_party/modernizr.min.js');?>"></script>
<!-- End Core JavaScript -->
<!-- JavaScript -->
<script src="<?=base_url('user-assets/js/login.js');?>"></script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
       <script type="text/javascript">
            $(function () {
                $("#datepicker1").datepicker({ 
                    autoclose: true, 
                    todayHighlight: true,
                    endDate: '-16y',
                }).datepicker('update', new Date());
            });

        </script>
        


<!-- End JavaScript -->
<?require_once('register-validation.php');?>
</body>
</html>
