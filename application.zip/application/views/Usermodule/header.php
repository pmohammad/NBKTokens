<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Adz Jar Home</title>
    <link rel="canonical" href="https://www.adzjar.com">
    <meta name="title" content="Adz Jar - Watch Videos and Get Paid">
    <meta name="referrer" content="unsafe-url">
    <meta name="description" content="Adz Jar Watch Videos and Get Paid">
    <link rel="icon" type="image/x-icon" href="<?=base_url('user-assets/images_temp/logo.svg');?>"  />
    <!-- App CSS -->
    <style>

        html {
            box-sizing: border-box;
        }
        *,
        *::before,
        *::after {
          box-sizing: inherit;
        }
        #ex1{
            height: auto;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
        }
        .close-modal {
            display:none !important;
        }
    </style>


    <!-- Pop Up CSS -->
    <link rel="stylesheet" href="<?=base_url('user-assets/css/pagination.css');?>">
    <!-- Remember to include jQuery :) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
    <!-- jQuery Modal -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css">
    <!-- Pop Up CSS -->
    <link rel="stylesheet" href="<?=base_url('../user-assets/fonts/fontawesome/css/solid.min.css');?>">
    <link rel="stylesheet" href="<?=base_url('../user-assets/fonts/fontawesome/css/fontawesome.min.css');?>">
    <link rel="stylesheet" href="<?=base_url('../user-assets/css/style.css');?>">
    <link rel="stylesheet" href="<?=base_url('../user-assets/css/custom.css');?>">
</head>
<body>

  <main class="main d-flex flex-row">

    <div class="mobile-menu shadow d-flex flex-row justify-content-between align-items-center d-md-none">
      <div class="mobile-menu__logo">
        <a href="<?=base_url('../Users/treasure');?>">
          <img src="<?=base_url('user-assets/images_temp/logo.svg');?>" alt="Adz Jar Logo">
        </a>
      </div> <!--/.mobile-menu__logo-->
      <div class="mobile-menu__open">
        <a href="javascript:;" id="menu-open">
          <svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
            <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
              <g id="HOME-Watch-Videos" transform="translate(-230.000000, -35.000000)" fill="#969BA1">
                <g id="Group-6" transform="translate(230.000000, 35.000000)">
                  <rect id="Rectangle" x="0" y="0" width="20" height="2" rx="1"></rect>
                  <rect id="Rectangle-Copy-6" x="0" y="9" width="12" height="2" rx="1"></rect>
                  <rect id="Rectangle-Copy-9" x="0" y="18" width="16" height="2" rx="1"></rect>
                </g>
              </g>
            </g>
          </svg>
        </a>
      </div>
    </div> <!--/.mobile-menu-->

    <!-- IT WILL GENERATE EMPTY SPACE -->
    <div class="sidebar-placeholder">
      <div class="sidebar shadow-lg d-flex flex-column justify-content-between" id="sidebar">
        <div class="sidebar-header">
          <div class="sidebar-brand d-flex flex-row justify-content-between align-items-center">

            <div class="sidebar-logo">
              <a href="<?=base_url('../Users/treasure');?>">
                <img src="<?=base_url('../user-assets/images_temp/logo.svg');?>" alt="AdzJar logo">
              </a>
            </div> <!--/.sidebar-logo-->

            <div class="sidebar-menu">
              <a href="javascript:;" class="d-md-none" id="menu-close">
                <svg width="30px" height="30px" viewBox="0 0 30 30" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="HOME-SideBar" transform="translate(-315.000000, -30.000000)" fill="#969BA1">
                      <g id="Group-6" transform="translate(315.000000, 30.000000)">
                        <g id="Group" transform="translate(15.000000, 15.000000) rotate(45.000000) translate(-15.000000, -15.000000) translate(5.000000, 5.000000)">
                          <rect id="Rectangle" x="0" y="9" width="20" height="2" rx="1"></rect>
                          <rect id="Rectangle-Copy" transform="translate(10.000000, 10.000000) rotate(90.000000) translate(-10.000000, -10.000000) " x="0" y="9" width="20" height="2" rx="1"></rect>
                        </g>
                      </g>
                    </g>
                  </g>
                </svg>
              </a>
            </div> <!--/.sidebar-menu-->
          </div> <!--/.sidebar-brand-->
          <nav class="sidebar-nav" role="navigation">

            <a href="<?=base_url('../Users/treasure');?>"
               class="sidebar-nav__item d-flex flex-row align-items-center active">
              <div class="sidebar-nav__icon">
                <svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="play-button" fill-rule="nonzero">
                      <path d="M19.9176224,9.63636364 C19.7504895,4.4027972 15.52,0.172447552 10.2865734,0.00531468531 C7.43888112,-0.085034965 4.77468531,0.998881119 2.80573427,3.03174825 C0.912867133,4.98601399 -0.0816783217,7.56237762 0.00531468531,10.2865734 C0.172307692,15.52 4.4027972,19.7504895 9.63622378,19.9174825 C9.74517483,19.920979 9.85314685,19.9226573 9.9613986,19.9226573 C12.6822378,19.9226573 15.2234965,18.846014 17.1170629,16.891049 C19.0099301,14.9369231 20.0046154,12.3604196 19.9176224,9.63636364 Z M15.6102098,15.4316084 C14.1153846,16.974965 12.1092308,17.8248951 9.9613986,17.8248951 C9.87552448,17.8248951 9.78965035,17.8234965 9.70307692,17.8208392 C5.57272727,17.688951 2.23398601,14.3502098 2.10195804,10.2197203 C2.03328671,8.06839161 2.81832168,6.03398601 4.31258741,4.49132867 C5.80741259,2.94797203 7.81356643,2.09804196 9.9613986,2.09804196 C10.0472727,2.09804196 10.1331469,2.09944056 10.2197203,2.1020979 C14.3500699,2.23398601 17.6888112,5.57272727 17.8208392,9.70321678 C17.8895105,11.8545455 17.1043357,13.888951 15.6102098,15.4316084 Z" id="Shape" fill="#999999"></path>
                      <path d="M13.2286713,9.38265734 L8.81132867,6.21538462 C8.34013986,5.87748252 7.6841958,6.21426573 7.6841958,6.79412587 L7.6841958,13.1288112 C7.6841958,13.7086713 8.34013986,14.0454545 8.81132867,13.7075524 L13.2285315,10.5401399 C13.6248951,10.2560839 13.6248951,9.66685315 13.2286713,9.38265734 Z" id="Path" fill="#999999"></path>
                    </g>
                  </g>
                </svg>
              </div> <!--/.side-nav__icon-->
              <div class="sidebar-nav__text">
                <span>Watch Videos</span>
              </div>
            </a> <!--/.sidebar-nav__item-->

            <a href="<?=base_url('../Users/dashboard');?>"
               class="sidebar-nav__item d-flex flex-row align-items-center">
              <div class="sidebar-nav__icon">
                <svg style="margin-left: 1px" width="19px" height="18px" viewBox="0 0 19 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="Video" transform="translate(-30.000000, -148.000000)" fill="#000000" fill-rule="nonzero">
                      <g id="Group-10" transform="translate(27.000000, 145.000000)">
                        <g id="nav-wallet" transform="translate(3.000000, 3.000000)">
                          <path fill="#999999" d="M18,4.28 L18,2 C18,0.9 17.1,0 16,0 L2,0 C0.89,0 0,0.9 0,2 L0,16 C0,17.1 0.89,18 2,18 L16,18 C17.1,18 18,17.1 18,16 L18,13.72 C18.59,13.37 19,12.74 19,12 L19,6 C19,5.26 18.59,4.63 18,4.28 Z M17,6 L17,12 L10,12 L10,6 L17,6 Z M2,16 L2,2 L16,2 L16,4 L10,4 C8.9,4 8,4.9 8,6 L8,12 C8,13.1 8.9,14 10,14 L16,14 L16,16 L2,16 Z" id="Shape"></path>
                          <circle fill="#999999" id="Oval" cx="13" cy="9" r="1.5"></circle>
                        </g>
                      </g>
                    </g>
                  </g>
                </svg>
              </div> <!--/.side-nav__icon-->
              <div class="sidebar-nav__text">
                <span>Wallet</span>
              </div>
            </a> <!--/.sidebar-nav__item-->

            <!--<a href="javascript:;"
               class="sidebar-nav__item d-flex flex-row align-items-center">
              <div class="sidebar-nav__icon">
                <svg style="margin-left: -1px" width="21px" height="18px" viewBox="0 0 21 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="HOME-Watch-Videos" transform="translate(-28.000000, -189.000000)" fill="#000000" fill-rule="nonzero">
                      <g id="nav-history" transform="translate(27.000000, 186.000000)">
                        <path fill="#999999" d="M13,3 C8.03,3 4,7.03 4,12 L1,12 L4.89,15.89 L4.96,16.03 L9,12 L6,12 C6,8.13 9.13,5 13,5 C16.87,5 20,8.13 20,12 C20,15.87 16.87,19 13,19 C11.07,19 9.32,18.21 8.06,16.94 L6.64,18.36 C8.27,19.99 10.51,21 13,21 C17.97,21 22,16.97 22,12 C22,7.03 17.97,3 13,3 Z M12,8 L12,13 L16.25,15.52 L17.02,14.24 L13.5,12.15 L13.5,8 L12,8 Z" id="Shape"></path>
                      </g>
                    </g>
                  </g>
                </svg>
              </div> <!--/.side-nav__icon
              <div class="sidebar-nav__text">
                <span>Watch History</span>
              </div>
            </a> <!--/.sidebar-nav__item-->

            <a href="<?=base_url('../Users/profile_details');?>"
               class="sidebar-nav__item d-flex flex-row align-items-center">
              <div class="sidebar-nav__icon">
                <svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <title>Shape</title>
                  <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="HOME-Watch-Videos" transform="translate(-29.000000, -229.000000)" fill="#000000" fill-rule="nonzero">
                      <g id="nav-profile" transform="translate(27.000000, 227.000000)">
                        <path fill="#999999" d="M12,6 C13.1,6 14,6.9 14,8 C14,9.1 13.1,10 12,10 C10.9,10 10,9.1 10,8 C10,6.9 10.9,6 12,6 M12,15 C14.7,15 17.8,16.29 18,17 L18,18 L6,18 L6,17.01 C6.2,16.29 9.3,15 12,15 M12,4 C9.79,4 8,5.79 8,8 C8,10.21 9.79,12 12,12 C14.21,12 16,10.21 16,8 C16,5.79 14.21,4 12,4 L12,4 Z M12,13 C9.33,13 4,14.34 4,17 L4,20 L20,20 L20,17 C20,14.34 14.67,13 12,13 L12,13 Z" id="Shape"></path>
                      </g>
                    </g>
                  </g>
                </svg>
              </div> <!--/.side-nav__icon-->
              <div class="sidebar-nav__text">
                <span>Profile</span>
              </div>
            </a> <!--/.sidebar-nav__item-->
            
            <a href="<?=base_url('../Users/logout');?>"
               class="sidebar-nav__item d-flex flex-row align-items-center">
               <div class="sidebar-nav__icon">
                 <img src="<?=base_url('user-assets/images_temp/logout.svg')?>" width="20px" height="20px">
               </div> <!--/.side-nav__icon-->
              <div class="sidebar-nav__text">
                <span>Logout</span>
              </div>
            </a> <!--/.sidebar-nav__item-->


          </nav> <!--/.sidebar-nav-->
        </div> <!--/.sidebar-header-->

        <div class="sidebar-footer">
          <div class="sidebar-account">
            <a href="javascript:;">
              <img src="<?=base_url("../".$this->session->profile);?>" alt="Account Image">
            </a>
            <h3><a href="javascript:;"><?=$this->session->uname;?></a></h3>
            <h4>KWD <?=$this->session->balance;?></h4>
            <!--<p>5 videos till next level</p>-->

            <!--<div class="sidebar-account__progress">
              <div class="sidebar-account__level" style="width: 70%;"></div>
            </div> <!--/.sidebar-account__progress-->

          </div> <!--/.sidebar-account-->
        </div> <!--/.sidebar-footer-->
      </div><!--/.sidebar-->
    </div> <!--/.sidebar-placeholder-->
    
    <div id="ex1" class="modal">
      <a href="<?=base_url('Users/treasure');?>"><button class="close" id="goback">×</button></a>
      <p style="padding-top: 10px;padding-left: 70px;" id="message"></p>
    </div>
    <?if($this->session->flashdata('error')){?>
        <script>
            var message = "<?=$this->session->flashdata('error');?>";
            $('#message').html(message);
            $( "#ex1" ).modal();
        </script>
    <?}if($this->session->flashdata('message')){?>
        <script>
            var message = "<?=$this->session->flashdata('message');?>";
            $('#message').html(message);
            $( "#ex1" ).modal();
        </script>
    <?}?>
