<?require_once('header.php');?>

<div class="login-card" style="display: block;margin-right: auto;margin-left: auto;">
	<div class="card shadow-sm">
		<div class="card-header bg-white border-0 p-0">
			<h1>Profile</h1>
		</div> <!--/.card-header-->
		<form method="POST" action="<?=base_url('Users/update_profile');?>" enctype="multipart/form-data">
              <div class="form-group">
                <label for="campaign-name">Full Name</label>
                <input type="hidden" id="id" class="form-control" name="id" value="<?=$user['01_id'];?>">
                <input type="text" id="name" class="form-control" name="name" value="<?=$user['01_name'];?>">
              </div> <!--/.form-group-->
              <div class="form-group">
                <label for="campaign-name">Profile Image</label>
                <img src="<?=base_url("../".$this->session->profile);?>" alt="Account Image">
                <input type="file" id="profile_image" class="form-control" name="profile_image" placeholder="Profile Image">
                <input type="hidden" id="profile_image_old" class="form-control" name="profile_image_old" placeholder="Profile Image" value="<?=$this->session->profile?>">
              </div> <!--/.form-group-->
              <div class="row">
                <div class="col-md-8">
                    <label for="campaign-cost">Interest</label>
                    <select name="interest[]" class='form-control tb_rules' multiple >
                        <option disabled>Select Interest</option>
                        <?foreach($interest as $int){?>
                            <option value="<?=$int['10_id'];?>" <?if (strstr($this->session->intid, $int['10_id'])){?>selected<?}?>><?=$int['10_interest'];?></option>
                        <?}?>
                    </select>
                </div> <!--/.col-md-6-->
              </div> <!--/.row-->
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="form-group pt-3">
                        <button type="submit" class="btn btn-danger btn-adzjar mr-2">Update</button>
                    </div> <!--/.form-group-->  
                </div>
                
            </form>
        </div>
    </div>
		
		
        
<?require_once('footer.php');?>