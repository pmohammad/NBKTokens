<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ini_set('display_errors', 0);
ini_set('display_startup_errors', 1);
error_reporting(0);

class Users extends CI_Controller {

    public $front="";
    public $back="";
#Constructor
    public function __construct() {
        parent::__construct();
        date_default_timezone_set('Asia/Kuwait');
        $this->load->model('Usermodel');
    }
#Function to call index page
    public function index(){
        $this->session->sess_destroy();
        $this->load->view('Usermodule/login');
    }

#Function to call register page
	public function register(){
	    $data['nationality'] = $this->Usermodel->get_nationality();
	    $data['language'] = $this->Usermodel->get_language();
	    $data['interest'] = $this->Usermodel->get_interest();
	    $data['gender'] = $this->Usermodel->get_gender();
		$this->load->view('Usermodule/register', $data);
	}

#Function to call forgot password page
	public function forgot_password(){
	    $this->load->view('Usermodule/forgot-password');
	}

#Function to call send email page
	public function send_email(){
	    error_reporting(1);
	    $email =  $this->input->post('email');
	    $verify = $this->Usermodel->verify_email($email);
	    if($verify) {
			$link = random_string('alnum', 10);
			$updateuser = $this->Usermodel->update_user($email,$link);
		    if($updateuser){
        	    $this->load->library('email');
                $fromemail="support@adzjar.com";
                $toemail = $email;
                $subject = "Requested to reset account password at Adzjar.com";
                $msg = $this->load->view('Usermodule/forgot-password-email','',true);
                $msg = str_replace('$$__SUBJECT__$$', $link, $msg);
                
                $config=array(
                'charset'=>'utf-8',
                'wordwrap'=> TRUE,
                'mailtype' => 'html'
                );
                
                $this->email->initialize($config);
                $this->email->to($toemail);
                $this->email->from($fromemail, "Reset Password at Adzjar.com");
                $this->email->subject($subject);
                $this->email->message($msg);
                $mail = $this->email->send();
                if($mail){
                    $this->session->set_flashdata('message', 'Email Sent...Please Check...');
                    return redirect('Users/index');
        		}else {
        		    $this->session->set_flashdata('error', 'Email Not Verified... Please check back');
        			return redirect('Users/forgot_password');
        		}
		    }
	    }
	}

#Function to change password
    public function change_password($link){
        $data['user'] = $this->Usermodel->get_userdata($link);
        if($data['user']==''){
            $this->session->set_flashdata('error', 'User Not Found');
            return redirect('Users/forgot_password');
        }
        else{
            $this->load->view('Usermodule/change-password', $data);
        }
    }

#Function to change password
    public function update_password(){
        $email =  $this->input->post('email');
        $password =  sha1($this->input->post('password'));
        $update = $this->Usermodel->update_password($email, $password);
        if($update){
            $this->session->set_flashdata('message', 'Password Updated');
            return redirect('Users/index');
        }
        else{
            $this->session->set_flashdata('error', 'Error in Updating Password');
            return redirect('Users/index');
        }
    }



#Function to check mobile number
    public function check_mobile(){
        $mobile = $_POST['mobile'];
        $result = $this->Usermodel->check_mobile($mobile);
        if($result!=="sent" && $result!=false && $result!='' && $result!==0){
            $otp = $this->db->where('number', $mobile)->where('is_sms', 0)->order_by('id', 'DESC')->limit(1)->get('verify_otp_12');
            $get_otp = $otp->row_array();
            $link = "OTP from adzjar.com is ".$get_otp['otp'];
            for ($i=0; $i<strlen($link); $i++){
                $ord = ord($link[$i]);
                $hexCode = dechex($ord);
                $hex .= substr('0'.$hexCode, -2);
            }
            $url = 'http://62.215.172.203/knews/easy_api_submit.aspx?un=ACC_716-059&pw=QdkXcE7J8xqsj52t&originator=544148534545454C&mobiles_list='.$mobile.'&msg_lang=en&msg_text='.$hex;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_POST, false);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            $xml = simplexml_load_string($response, "SimpleXMLElement", LIBXML_NOCDATA);
            $json = json_encode($xml);
            $res = json_decode($json,TRUE);
            echo json_encode($result);
            $this->db->where('number', $mobile)->set('is_sms', 1)->update('verify_otp_12');
        }else if($result==true){
            echo json_encode($result);
        }
        else if($result==0){
            echo json_encode(false);
        }
    }

#Function to check mobile number
    public function check_email(){
        $email = $_POST['email'];
        $result = $this->Usermodel->check_email($email);
        if($result!=="sent" && $result!=false && $result!='' && $result!==0){
            $otp = $this->db->where('number', $email)->where('is_sms', 0)->order_by('id', 'DESC')->limit(1)->get('verify_otp_12');
            $get_otp = $otp->row_array();
            $this->load->library('email');
            $fromemail="info@adzjar.com";
            $toemail = $email;
            $subject = "Email account Verification at Adzjar.com";
            $msg = $this->load->view('Usermodule/otp-email','',true);
            $msg = str_replace('$$__OTP__$$', $get_otp['otp'], $msg);
            $config=array(
                'charset'=>'utf-8',
                'wordwrap'=> TRUE,
                'mailtype' => 'html'
            );
            $this->email->initialize($config);
            $this->email->to($toemail);
            $this->email->from($fromemail, "Email verification at Adzjar.com");
            $this->email->subject($subject);
            $this->email->message($msg);
            $mail = $this->email->send();
            if($mail){
                $this->db->where('number', $email)->set('is_sms', 1)->update('verify_otp_12');
                echo json_encode(true);
            }else {
                echo json_encode(false);
            }
        }else if($result==true){
            echo json_encode($result);
        }
        else if($result==0){
            echo json_encode(false);
        }
    }

#Function to check mobile otp
    public function check_otp(){
        $otp = $_POST['otp'];
        $mobile = $_POST['mobile'];
        $res = $this->Usermodel->check_otp($mobile, $otp);
        echo json_encode($res);
    }

#Function to check referral
    public function check_referral(){
        $referral = $_POST['referral'];
        $result = $this->Usermodel->check_referral($referral);
        echo json_encode($result);
    }

#Function to update wallet balance
    public function wallet_balance(){
        $uid = $this->session->uid;
        $bal = $this->Usermodel->get_userbalance($uid);
        if($bal['09_balance']!=''?$balance = $bal['09_balance']:$balance = '0.000');
        $this->session->set_userdata('balance',$balance);
    }
    
    
#Function to complete registration
	public function registration(){
	    $name = $this->input->post('name');
	    $mobile = $this->input->post('mobile');
	    $email = $this->input->post('email');
        $nationality = $this->input->post('nationality');
        $referral = $this->input->post('referralid');
        $language = $this->input->post('language');
        $gender = $this->input->post('gender');
        $dob = date_create($this->input->post('tdate'));
        $interest = $this->input->post('interest');
        $pass = sha1($this->input->post('password'));
        $interest = implode(',', $interest);
        $d = date_create(date('Y-m-d'));
        $diff = date_diff($dob,$d);
        $dob = $diff->format('%y');
        
        $age = $this->Usermodel->get_agegroup();
        foreach($age as $key){
            $arrAge = explode('-', $key['13_age']);
            if($dob>=$arrAge[0] && $dob<=$arrAge[1]){
                $dob = $key['13_id'];
            }
        }
        $register = $this->Usermodel->registration($name,$mobile,$nationality,$referral,$pass,$email, $gender, $dob, $interest,$language);
        $token=md5(uniqid());
        $update_token = $this->Usermodel->update_token($register['01_id'], $token);
		if($register) {
		    $this->session->set_userdata('token', $token);
			$this->session->set_userdata('is_user', true);
			$this->session->set_userdata('mobile',$register['01_mobile']);
			$this->session->set_userdata('uid',$register['01_id']);
            $this->session->set_userdata('uname',$validate['01_name']);
			$this->session->set_userdata('natid',$register['01_nationality']);
			$this->session->set_userdata('intid',$register['01_interest']);
			$this->session->set_userdata('lanid',$register['01_language']);
			$this->session->set_userdata('genid',$register['01_gender']);
			$this->session->set_userdata('ageid',$register['01_age']);
			$this->session->set_userdata('profile',$register['01_profile_photo']);
			$this->session->set_userdata('is_bank_details',$register['is_bank_details']);
			//function to update wallet balance
            $this->wallet_balance();
			return redirect('Users/treasure');
		} else {
			$this->session->set_flashdata('error', 'Error Occured!!');
			return redirect('Users/register');
		}
	}

  #Function to call Treasure
      public function treasure(){
        $this->checkLogin();
        $uid = $this->session->uid;
        
        //set session variable for load more
        if($this->session->camp_ids!=''){
            $newer = $this->session->camp_ids;
        }else{
            $newer = 0;
        }
        
        //function to update wallet balance
        $this->wallet_balance();
        $data['treasure'] = [];
  		$data['treasure'] = $this->Usermodel->fetch_thumbnails($uid, $newer);
        $data['p'] = 0;
        $data['camp_ids'] = $this->Usermodel->get_camp_ids($uid,$newer);
        $this->session->set_userdata('camp_ids',$data['camp_ids']);
        $this->load->view('Usermodule/treasure', $data);
    }

# Function to verify USers
	function checkLogin() {
	    $uid = $this->session->uid;
	    $get_token = $this->Usermodel->get_token($uid);
	    $token = $this->session->token;
		if(!$this->session->is_user || $token!==$get_token) {
			# Okay, you ain't clear to go, back to login now
			return redirect('Users?error=Session expired, please login to continue.');
		}
	}

#Function to call login
    public function login(){
        $mobile = $_POST['mobile'];
        $pass = sha1($_POST['password']);
        $validate = $this->Usermodel->validate_login($mobile,$pass);
        if($validate){
            $token=md5(uniqid());
            $update_token = $this->Usermodel->update_token($validate['01_id'], $token);
            $this->session->set_userdata('token', $token);
            $this->session->set_userdata('is_user', true);
      			$this->session->set_userdata('mobile',$validate['01_mobile']);
      			$this->session->set_userdata('uid',$validate['01_id']);
            $this->session->set_userdata('uname',$validate['01_name']);
      			$this->session->set_userdata('natid',$validate['01_nationality']);
      			$this->session->set_userdata('intid',$validate['01_interest']);
      			$this->session->set_userdata('lanid',$validate['01_language']);
      			$this->session->set_userdata('genid',$validate['01_gender']);
      			$this->session->set_userdata('ageid',$validate['01_age']);
      			$this->session->set_userdata('profile',$validate['01_profile_photo']);
      			$this->session->set_userdata('is_bank_details',$validate['is_bank_details']);
                //function to update wallet balance
                $this->wallet_balance();
                $this->session->set_userdata('camp_ids','');
      			echo json_encode('true');
        }else{
            echo json_encode('false');
            //$this->session->set_flashdata('error', 'Incorrect Details');
			      //return redirect('Users/index');
        }
    }

#Function to call dashboard
    public function dashboard(){
        $this->checkLogin();
        $id = $this->session->uid;
        $this->wallet_balance();
        $data['wallet'] = $this->Usermodel->get_wallet($id);
        
        //function to update wallet balance
        $data['balance'] = $this->Usermodel->get_userbalance($id);
        $data['kyc'] = $this->Usermodel->get_kyc_info($id);
        $this->load->view('Usermodule/dashboard', $data);
    }

  #Function to fetch wallet
  public function fetch_wallet(){
    $this->checkLogin();
    $id = $this->session->uid;
    $order = $this->input->post("order");
    $col = 0;
    $dir = "";
        if(!empty($order))
        {
            foreach($order as $o)
            {
                $col = $o['column'];
                $dir= $o['dir'];
            }
        }

        if($dir != "asc" && $dir != "desc")
        {
            $dir = "desc";
        }

        $data = $this->Usermodel->fetch_wallet($id);
        $amount = $this->Usermodel->get_wallet_amount($id);
        $wallets = [];
        foreach($data as $key)
        {
          $date=$key['09_date'];
          $expire=$newEndingDate = date("Y-m-d", strtotime(date("Y-m-d", strtotime($date)) . " + 364 day"));
          $wallets[]= array(
              $key['09_id'],
            $date,
            $key['09_description'],
            $expire,
            $key['09_earn']>0.000?$key['09_earn']:'',
            $key['09_withdraw']>0.000?$key['09_withdraw']:'',
            $key['09_balance'],
          );
          $amount = $amount - $key["09_effective_balance"];
        }
        $total_orders = $this->total_records();
        $output = array(
          "draw" => 0,
          "recordsTotal" => $total_orders,
          "recordsFiltered" => $total_orders,
          "data" => $wallets
        );
        echo json_encode($output);
  }

  public function total_records(){
        $query = $this->db->select("COUNT(*) as num")->get("wallet_09");
        $result = $query->row();
        if(isset($result)) return $result->num;
        return 0;
    }


#Function to call profile details
    public function profile_details(){
        $this->checkLogin();
        $this->wallet_balance();
        $id = $this->session->uid;
        if($this->session->is_bank_details==0){
            $data['user'] = $this->Usermodel->fetch_profile_details($id);
        }else{
            $data['user'] = $this->Usermodel->fetch_bank_profile($id);
        }
        $this->load->view('Usermodule/profile-details', $data);
    }

#Function to call Watch history
    public function watch_history(){
        $this->checkLogin();
        $id = $this->session->uid;
        $data['history'] = $this->Usermodel->watch_history($id);
        $this->load->view('Usermodule/watch-history', $data);
    }

#Function to view Video
    public function video($id, $id6){
        $this->checkLogin();
        $uid = $this->session->uid;
        $this->wallet_balance();
        $update = $this->Usermodel->add_history($id,$uid,$id6);
        if($update==="true"){
            $data['vid'] = $this->Usermodel->fetch_video($id6);
            $this->load->view('Usermodule/video', $data);
        }else if($update>0 && $update!=="false"){
            return redirect('../Users/treasure/');
        }else if($update==-1){
            $this->session->set_flashdata('error', 'Campaign Paused.');
            return redirect('../Users/treasure/');
        }else{
            return redirect('../Users/treasure/');
        }
    }

#Function to load history video
    public function history($id){
        $this->checkLogin();
        $uid = $this->session->uid;
        $data['vid'] = $this->Usermodel->fetch_history_video($id,$uid);
        if(isset($data['vid'])){
            $this->load->view('Usermodule/video', $data);
        }else{
            return redirect('Users/treasure/');
        }

    }

#Function to update set_timeout
    public function set_timeout(){
        $this->checkLogin();
        $time = $_POST['time'];
        $id6 = $_POST['id'];
        $type = $_POST['type'];
        $uid = $this->session->uid;
        $data = $this->Usermodel->set_timeout($uid, $time, $id6,$type);
        echo json_encode($data);
    }

#Function to add money
    public function add_money(){
        $this->checkLogin();
        $time = $_POST['time'];
        $type = $_POST['type'];
        $uid = $this->session->uid;
        $data = $this->Usermodel->add_money($uid, $time,$type);
        echo json_encode($data);
    }

#Function to update bank account
    public function update_bankdetails(){
        $this->checkLogin();
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		$rules = array(
			array(
				'field' => 'civil_front',
				'label' => 'Civil ID (Front)',
				'rules' => 'callback_upload_civil_front'
			),
			array(
				'field' => 'civil_back',
				'label' => 'Civil Id (Back)',
				'rules' => 'callback_upload_civil_back'
			),
		);
		$this->form_validation->set_rules($rules);
		if($this->form_validation->run() == FALSE) {
		    return redirect('Users/profile_details', $data );
		} else {
			$this->bank_details();
		}
    }
#Function to validate image file
	function upload_civil_front() {
		$config['upload_path'] = './user-assets/images/customer-documents/';
		$config['allowed_types'] = 'jpg|png|jpeg';
		$config['remove_spaces'] = true;
		$config['quality'] = '50%';

		$this->load->library('upload');
        $this->upload->initialize($config);

		if($this->upload->do_upload('civil_front')) {
		    $this->upload->data();
		    $this->front = $this->upload->data('file_name');
			return true;

		} else {
			$this->session->set_flashdata('error', 'Civil Id Front: '.$this->upload->display_errors());
			return false;
		}
	}

# Function to validate image file
	function upload_civil_back() {
		$config['upload_path'] = './user-assets/images/customer-documents/';
		$config['allowed_types'] = 'jpg|png|jpeg';
		$config['remove_spaces'] = true;
		$config['quality'] = '60%';
		$this->load->library('upload');
        $this->upload->initialize($config);
		if($this->upload->do_upload('civil_back')) {
		    $this->upload->data();
			$this->back = $this->upload->data('file_name');
			return true;
		} else {
			$this->session->set_flashdata('error', 'Civil Id Back: '.$this->upload->display_errors());
			return false;
		}
	}

#Function to Add bank Details
    public function bank_details(){
        $this->checkLogin();
        $id = $this->session->uid;
        $iban = $this->input->post('hash');
        $acc_name = $this->input->post('acc_name');
        $banks = $this->input->post('banks');
		$civil_front = './user-assets/images/customer-documents/'.$this->front;
		$civil_back = './user-assets/images/customer-documents/'.$this->back;

		$details = $this->Usermodel->bank_details($id,$civil_front,$civil_back,$iban,$acc_name,$banks);
        if($details){
            $this->session->set_userdata('is_bank_details',1);
            $this->session->set_flashdata('message', 'Bank details updated... Waiting for approval');
		    return redirect('Users/profile_details');
        }
        else{
            $this->session->set_flashdata('error', 'Error in withdrawals... Please try again after sometime');
		    $this->load->view('Users/profile_details');
        }
    }

#Function to request withdrawal
    public function request_withdraw(){
        $this->checkLogin();
        $id = $this->input->post('id');
        $pass = sha1($this->input->post('hash'));
        $details = $this->Usermodel->request_withdraw($id,$pass);
        if($details){
            $this->session->set_flashdata('message', 'Success... Withdrawal is waiting for confirmation');
		    return redirect('Users/dashboard');
        }
        else{
            $this->session->set_flashdata('error', 'Error in withdrawals... Please try again after sometime');
		    return redirect('Users/dashboard');
        }
    }

#Function to edit profile
    public function edit_profile(){
        $this->checkLogin();
        $id = $this->session->uid;
        $data['user'] = $this->Usermodel->edit_profile($id);
        $data['interest'] = $this->Usermodel->get_interest();
        $this->load->view('Usermodule/edit-profile', $data);
    }

#Function to update profile
    public function update_profile(){
        $this->checkLogin();
        $id = $this->session->uid;
        $name = $this->input->post('name');
        $interest = $this->input->post('interest');
        $interest = implode(',', $interest);
        if($_FILES['profile_image']['name']!=""){
    	    $config['upload_path'] = 'user-assets/images_temp/';
    		$config['allowed_types'] = 'jpg|png|jpeg';
    		$config['remove_spaces'] = true;
    		$this->load->library('upload');
            $this->upload->initialize($config);
    		if(!$this->upload->do_upload('profile_image')) {
    			$this->session->set_flashdata('error', $this->upload->display_errors());
    			$this->edit_profile();
    			
    		} else {
    			$this->upload->data();
    			$profile = array(
                    '01_name' =>$name,
                    '01_interest' =>$interest,
                    '01_profile_photo' =>'user-assets/images_temp/'.$this->upload->data('file_name'),
                );
                $update = $this->db->where('01_id', $id)->update('register_01', $profile);
                if($update){
                    $this->session->set_userdata('profile','user-assets/images_temp/'.$this->upload->data('file_name'));
                    $this->session->set_userdata('intid',$interest);
                    $this->session->set_flashdata('message', 'Profile updated!!!');
		            return redirect('Users/profile_details');
                }else{
                    die();
                }
    		}
        }
        else{
            $profile = array(
                '01_name' =>$name,
                '01_interest' =>$interest,
            );
            $update = $this->db->where('01_id', $id)->update('register_01', $profile);
            if($update){
                $this->session->set_userdata('intid',$interest);
                $this->session->set_flashdata('message', 'Profile updated!!!');
                return redirect('Users/profile_details');
            }else{
                die();
            }
        }
        
        
    }

#Function to add details
    public function add_bank_details(){
        $id = $this->session->uid;
        $data['user'] = $this->Usermodel->edit_profile($id);
        $data['banks'] = $this->Usermodel->fetch_banks();
        $this->load->view('Usermodule/bank-details', $data);
    }

#Function to update details
    public function update_user_bank(){
        $id = $this->session->uid;
        $update = array(
            '16_account_name' =>$this->input->post('acc_name'),
            '16_iban' =>$this->input->post('hash'),
            'bank_id' =>$this->input->post('banks'),
            'is_verify' => 0,
        );
        
        $set = $this->db->where('01_id', $id)->update('bank_details_16', $update);
        if($set){
            $this->session->set_flashdata('message', 'Bank details updated!!!');
            return redirect('Users/profile_details');
        }else{
            die();
        }
    }
    
#Function to edit details
    public function edit_bank_details(){
        $id = $this->session->uid;
        $data['bank_details'] = $this->Usermodel->edit_bank_details($id);
        $data['banks'] = $this->Usermodel->fetch_banks();
        $this->load->view('Usermodule/edit-bank', $data);
    }
    
    

# Logout users
	public function logout() {
	    $this->checkLogin();
		$this->session->sess_destroy();
		return redirect('../Users/index');
	}
}
